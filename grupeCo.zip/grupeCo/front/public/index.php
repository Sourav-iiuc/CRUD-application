<!DOCTYPE html>
<html lang="en">
<?php
include_once ($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
include_once ('../views/elements/head.php');
?>
<body>
<!--     markup for header-->
    <?php
        include_once ('../views/elements/header.php');
//    <!-- markup for banner-->
        include_once ('../views/elements/banner.php');
//    <!-- markup for services-->

        include_once ('../views/elements/services.php');
        //<!-- markup for featured products-->


        include_once ('../views/elements/featured-product.php');





        //<!-- markup for new products-->
        include_once ('../views/elements/new-product.php');

        //<!-- markup for footer-->
        include_once ('../views/elements/footer.php');

        //<!-- adding js file-->
        include_once ('../views/elements/script.php');
     ?>
</body>
</html>