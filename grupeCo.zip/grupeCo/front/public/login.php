<?php include_once($_SERVER['DOCUMENT_ROOT'] . '/grupeCo/config.php');?>
<!doctype html>
<html lang="en">
<?php include_once ('../views/elements/login-head.php');?>
<body>
<!--Header-->
<?php
include_once ('../views/elements/header.php');


//<!--body content-->
include_once ('../views/elements/login-contant.php');

//<!-- markup for footer-->
include_once ('../views/elements/footer.php');

//<!-- jQuery first, then Popper.js, then Bootstrap JS -->
include_once ('../views/elements/script.php');
?>
</body>
</html>