<?php
$approot = $_SERVER['DOCUMENT_ROOT'].'/grupeCo/';
$webroot = 'http://localhost/grupeCo';
include_once($approot.'vendor/autoload.php');

use App\Cart;

$_POST['total_price'] = $_POST['qty'] * $_POST['unit_price'];
$_cart = new Cart();
$_cart->add_to_cart();




header("location:http://localhost/grupeCo/front/public/product.php");


?>