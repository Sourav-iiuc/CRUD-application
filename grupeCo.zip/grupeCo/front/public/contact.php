<!doctype html>
<html lang="en">
<?php include_once ('../views/elements/contact-head.php'); ?>

<body>
<!--Markup for header-->

    <?php
        include_once ('../views/elements/header.php');


         include_once ('../views/elements/contact-body.php');

        //<!--Markup for footer-->
         include_once ('../views/elements/footer.php');

        //<!-- adding js file-->
         include_once ('../views/elements/script.php');
    ?>
</body>
</html>