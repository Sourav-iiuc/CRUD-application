<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
use App\Cart;
?>


<!DOCTYPE html>
<html lang="en">
<?php include_once ('../views/elements/cart-head.php');?>

<body>

<!--markup for header-->
    <?php
        include_once ('../views/elements/header.php');




        //<!--Main starts-->

         include_once ('../views/elements/cart-product.php');


        //<!--second cart item starts-->
//         include_once ('../views/elements/cart-product-2.php');

        //<!--    second cart item ends




         include_once ('../views/elements/cart-button.php');

        //<!-- markup for footer-->
         include_once ('../views/elements/footer.php');

        //<!-- adding js file-->
         include_once ('../views/elements/script.php');
    ?>



</body>
</html>