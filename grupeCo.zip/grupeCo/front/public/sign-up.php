<?php
include_once($_SERVER['DOCUMENT_ROOT'] . '/grupeCo/config.php');
include_once('../views/elements/head.php');

include_once('../views/elements/header.php');
include_once('../views/elements/sign-up.php');

include_once('../views/elements/footer.php');
include_once('../views/elements/script.php');

?>