<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
use App\Product;
?>
<!doctype html>
<html lang="en">
<?php
include_once ('../views/elements/product-head.php')?>
<body>
<!--Markup for header-->
    <?php
        include_once ('../views/elements/header.php');
    //<!--End of Header-->
    //<!--Markup for bredcum-->
        include_once ('../views/elements/breadcrumb.php');



    //<!--markup for products body-->


    //<!--catagory-->
        include_once ('../views/elements/catagory.php');

    //<!--catagory end-->
    //<!-- Best product-->
        include_once ('../views/elements/new-product1.php');

    //<!--discount banner-->
        include_once ('../views/elements/discount-banner.php');

    //<!--tranding product-->
        include_once ('../views/elements/tranding-product.php');



    //<!--Best sold products-->
        //include_once ('../views/elements/best-sold-product.php');


    //<!--More products-->

        include_once ('../views/elements/more-product.php');

    //<!--murkup for tool bar-->

        include_once ('../views/elements/toolbar.php');

    //<!--Markup for footer-->
        include_once ('../views/elements/footer.php');
    //<!--End of footer-->


    //<!--java script files-->
        include_once ('../views/elements/script.php');
    ?>

</body>
</html>