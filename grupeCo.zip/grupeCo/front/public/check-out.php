<!doctype html>
<html lang="en">
<?php include_once ('../views/elements/check-out-head.php'); ?>
<body>
<!-- header-->
    <?php
        include_once ('../views/elements/header.php');


        //<!--all body element-->

         include_once ('../views/elements/check-out-body.php');
        //	<!-- markup for footer-->
         include_once ('../views/elements/footer.php');

        //<!--Script-->
         include_once ('../views/elements/script.php');
     ?>
</body>
</html>




