<?php

use App\Banner;
$_banner=new Banner();
$banners=$_banner->getActiveBanners();

?>


<div id="my-carousel" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#my-carousel" data-slide-to="0" class="active"></li>
        <li data-target="#my-carousel" data-slide-to="1"></li>
        <li data-target="#my-carousel" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
        <?php
        $active = 'active';
        foreach ($banners as $banner):
            ?>
            <div class="carousel-item <?php echo $active; ?>">
                <img src="<?php echo $webroot?>/uploads/<?php echo $banner['picture']?>" class="d-block w-100" alt="banner"
                     style="border: 1px solid black" height="700" width="900">
                <div class="carousel-caption d-none d-md-block">
                    <h5 style="color: #005cbf"><?php echo $banner['title']?></h5>
                    <p style="color:#005cbf "><?php echo $banner['detail']?></p>
                </div>
            </div>
            <?php
            $active = '';
        endforeach;

        ?>
    </div>
    <a class="carousel-control-prev" href="#my-carousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#my-carousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>
