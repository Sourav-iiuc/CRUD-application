<div class="container">
    <h3 style="text-align: center; background-color: #8c8e94; margin:auto;padding: 10px 0px 10px 0px">Featured Products</h3>
    <div class="card-group">
        <div class="card">
            <img src="img/1.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">HUBLOT Watch</h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
            </div>
            <div class="card-footer">
                <small class="text-muted">Last updated 11 mins ago</small>
                <br>
                <button class="btn btn-outline-secondary" type="button" href="#">Add To Cart</button>
            </div>
        </div>
        <div class="card">
            <img src="img/2.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Xiaomi Mi 9 128GB + 6GB RAM</h5>
                <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
            </div>
            <div class="card-footer">
                <small class="text-muted">Last updated 17 mins ago</small>
                <br>
                <button class="btn btn-outline-secondary" type="button" href="#">Add To Cart</button>
            </div>
        </div>
        <div class="card">
            <img src="img/3.jpg" class="card-img-top" alt="product 3">
            <div class="card-body">
                <h5 class="card-title">Electric Blender</h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
            </div>
            <div class="card-footer">
                <small class="text-muted">Last updated 35 mins ago</small>
                <br>
                <button class="btn btn-outline-secondary" type="button" href="#">Add To Cart</button>
            </div>
        </div>
    </div>
</div>