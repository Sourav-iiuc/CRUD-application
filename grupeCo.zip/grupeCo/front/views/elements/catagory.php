<ul class="list-group" id="catagory">
    <li class="list-group-item "><strong>CATAGORY</strong></li>
    <li class="list-group-item "><a href="#new-product">New Product</a></li>
    <li class="list-group-item"><a href="#tranding">TRANDING</a></li>
    <li class="list-group-item"><a href="#best-sold">Best SOld</a></li>
    <li class="list-group-item"><a href="#more_products">Brand</a></li>
    <li class="list-group-item"><a href="#">MEN</a> </li>
    <li class="list-group-item"><a href="#">women</a> </li>
    <li class="list-group-item"><a href="#">other</a> </li>
    <li class="list-group-item"><a href="#">Computer</a> </li>
</ul>