<?php
//include_once($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
//include_once($_SERVER['DOCUMENT_ROOT'].'/grupeCo/authenticator.php');
$webroot = 'http://localhost/grupeCo/';
?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.html"><i class="fas fa-home"></i></a></li>
        <li class="breadcrumb-item active" aria-current="page">contact</li>
    </ol>
</nav>

<section id="map">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3651.9021897295593!2d90.3913638153078!3d23.750867094674643!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b8bd552c2b3b%3A0x4e70f117856f0c22!2sBASIS%20Institute%20of%20Technology%20%26%20Management%20(BITM)!5e0!3m2!1sen!2sbd!4v1569924090797!5m2!1sen!2sbd" width="100%" height="400" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
</section>

<div class="container">
    <div class="row" id="mostafa1">
        <div class="col-sm-8">
            <form action="<?=$webroot?>admin/Contacts/store.php">

                <div class="form-group required-field">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div><!-- End .form-group -->

                <div class="form-group required-field">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div><!-- End .form-group -->

                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input type="text" class="form-control" id="subject" name="subject">
                </div><!-- End .form-group -->

                <div class="form-group required-field">
                    <label for="message">What’s on your mind?</label>
                    <textarea cols="30" rows="1" id="message" class="form-control" name="message" required></textarea>
                </div><!-- End .form-group -->
                <button type="button" class="btn btn-success">Submit</button>
            </form>

        </div>
        <div class="col-sm-4" id="info1">
            <ul class="list-group">
                <li class="list-group-item"><i class="fas fa-envelope" id="mostafa"></i>mostafa@gmail.com</li>
                <li class="list-group-item"><i class="fab fa-twitter" id="mostafa"></i>twitter.com/mostafa</li>
                <li class="list-group-item"><i class="fab fa-facebook" id="mostafa"></i>fb.com/mostafa</li>
                <li class="list-group-item"><i class="fab fa-skype" id="mostafa"></i>mostafa@skype</li>
            </ul>

        </div>
    </div>
</div>