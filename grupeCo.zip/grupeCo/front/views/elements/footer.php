<footer>
    <div class="footer-top" id="foot-col">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3 col-md-4 col-sm-6 ">
                    <h3>Website Name</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Et, laborum magni numquam porro quibusdam reiciendis repellat.</p>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <h3>Useful Links</h3>
                    <ul type="none">
                        <li><a href="index.php" style="color: black">HOME</a></li>
                        <li><a href="product.php" style="color: black">PRODUCT</a></li>
                        <li><a href="cart.php" style="color: black">CART</a></li>
                        <li><a href="check-out.php" style="color: black"> CHECH-OUT</a></li>
                        <li><a href="login.php" style="color: black"> LOGIN</a></li>
                        <li><a href="contact.php" style="color: black">CONTACT</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 ">
                    <h3>Contact US</h3>
                    <p>
                        Goalpahar Circle<br>
                        Chittagong ,Bangladesh<br>

                        <strong>Call us:</strong>+123456789<br>
                        <strong>Email:</strong>website@gmail.com<br><br>
                    </p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-twitter" style="padding-right: 10px"></i></i></a>
                        <a href="#"><i class="fab fa-facebook" style="color: "></i></i></a>
                        <a href="#"><i class="fab fa-instagram" style="color:"></i></i></a>
                        <a href="#"><i class="fab fa-google-plus" style="color:"></i></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 footer-newsletter">
                    <h3>Ous Newsletter</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p><br>
                    <form action="" method="post">
                        <input type="email" name="email"><input type="submit" value="Submit">
                    </form>
                </div>

            </div>
        </div>
    </div>
    </div>
    <div class="footer-bottom container-fluid">
        <div class="copyright">
            &copy; Copyright &nbsp;<strong>WebsiteName</strong>.All Rights Reserved.
        </div>
        <div class="credits" style="padding-right: 0px">
            Designed By <a href="#">WebsiteName</a>
        </div>
    </div>
</footer>