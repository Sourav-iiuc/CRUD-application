<header class="header">
    <div class="header-top ">
        <div class="container">
            <div class="row">
                <div class="col-3">
                    <p class="welcome-message" style="padding-top: 15px"><marquee style="width280px; color:#a500ff;">Welcome To Our Site!</marquee>  </p>
                </div>
                <div class="col9 d-none d-lg-block">
                    <ul class="nav">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">HOME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="product.php">PRODUCT</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="cart.php">CART</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="check-out.php">CHECK-OUT</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">LOGIN</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">CONTACT</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link">
                                <div class="input-group mb-3 ml-auto">
                                    <input type="text" class="form-control" placeholder="Search Your Item" aria-label="Recipient's username" aria-describedby="basic-addon2">
                                    <div class="input-group-append">
                                        <button type="button" class="btn btn-success"><i class="fas fa-search"></i>

                                        </button>
                                    </div>









                                </div>
                            </a>
                        </li>
                    </ul>

                </div>

                <div class="col-9 d-lg-none">
                    <ul class="nav">
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="fas fa-user"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="fab fa-amazon-pay"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="fas fa-cart-plus"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="fas fa-blog"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="fas fa-address-book"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="fas fa-sign-out-alt"></i></a>
                        </li>
                        <button type="button" class="btn btn-success"><i class="fas fa-search"></i>

                        </button>
                </div>
            </div>
            </a>
            </li>
            </ul>

        </div>

    </div>

    </div>
    </div><!-- End .header-top -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark" style="background-color:#fff">
        <div class="container">
            <a class="navbar-brand" href="index.php"><img src="img/logo.png" alt="Brand Image"  height="250px" width="250px" class="img-fluid"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#myNav" aria-controls="myNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="myNav">
                <ul class="navbar-nav  ml-auto" >
                    <li class="nav-item active" ><a href="#" class="nav-link" style="color: white">MY ACCOUNT <span class="sr-only">(current)</span></a></li>
                    <li class="nav-item"><a href="#" class="nav-link" style="color: white">WISHLIST</a></li>
                    <li class="nav-item"><a href="#" class="nav-link" style="color: white">MY ORDER</a></li>
                    <li class="nav-item"><a href="#" class="nav-link" style="color: white">VOUCHAR</a></li>
                    <li class="nav-item"><a href="#" class="nav-link" style="color: white">PROFILE</a></li>
                    <li class="nav-item"><a href="#" class="nav-link" style="color: white">SETTINGS</a></li>
                </ul>
            </div>
        </div>
    </nav>
</header>