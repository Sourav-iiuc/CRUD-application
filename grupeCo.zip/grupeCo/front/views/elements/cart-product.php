<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
//$approot= $_SERVER['DOCUMENT_ROOT'].'/grupeCo/';
//$webroot="http://localhost/grupeCo/";
//include_once ($approot.'vendor/autoload.php');
use App\Cart;
$_cart = new Cart();
$carts = $_cart->index();
?>







<?php
if(count($carts)>0):
foreach ($carts as $cart) :
?>


<div class="container-fluid">
    <div class="raw">
        <div id="product">

            <div class="row">

                <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 align-content-center" id="imgsize">
                    <img src="<?php echo $webroot; ?>/uploads/<?php echo $cart['picture'];?>" alt="product" class="img-fluid" id="imgres">
                </div>

                <div class="col-lg-3 col-md-12 col-sm-12 protext">
                    <h4 class="display-4"><?php echo $cart['product_title']?></h4>
                </div>

                <div class="col-lg-2 col-md-12 col-sm-12 protext fontSizzing">
                    <span>PRICE</span>
                    <hr width="50%">
                    <p class="card-text"><?php echo $cart['unit_price']?></p>
                </div>

                <div class="col-lg-1 col-md-12 col-sm-12 protext pt-2 pb-2">
                    <span>Quantity</span>
                    <hr width="40%">
                    <p class="card-text"><?php echo $cart['qty']?></p>
                </div>
                <div class="col-lg-2 col-md-12 col-sm-12 protext fontSizzing pb-md-2 pb-sm-2 pb-xs-2" id="fonthov">
                    <span>TOTAL</span>
                    <hr width="50%">
                    <p class="card-text"><?php echo $cart['total_price']?></p>
                </div>
                <div class="col-lg-1 col-md-12 col-sm-12 protext fontSizzing pb-md-2 pb-sm-2 pb-xs-2" id="fonthov">
                    <a href="<?=$webroot;?>admin/cart/delete.php?id=<?php echo $cart['id']?>"><i class="fa fa-trash " aria-hidden="true"></i></a>
                </div>


            </div>






        </div>


    </div>

</div>


<?php
endforeach;
else:
    ?>
    <tr>
        <td colspan="6"> No Item <in></in> Cart is Available. <a href="create.php">Click here to add one</a></td>
    </tr>
<?php
endif;
?>