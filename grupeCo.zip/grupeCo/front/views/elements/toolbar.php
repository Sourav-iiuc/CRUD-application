<div class="container">
    <div class="btn-toolbar" role="toolbar" aria-label="Toolbar with button groups" id="space">
        <div class="btn-group mr-2" role="group" aria-label="First group" >
            <a href="#"><button type="button" class="btn btn-secondary">1</button></a>

        </div>
        <div class="btn-group mr-2" role="group" aria-label="Second group">

            <a href="#"> <button type="button" class="btn btn-secondary">2</button></a>
        </div>
        <div class="btn-group mr-2" role="group" aria-label="Second group">

            <a href="#"><button type="button" class="btn btn-secondary">3</button></a>
        </div>
        <div class="btn-group" role="group" aria-label="Third group">
            <a href="#"><button type="button" class="btn btn-secondary">Next Page</button></a>
        </div>
    </div>
</div>