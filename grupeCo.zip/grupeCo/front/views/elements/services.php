<section>
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <div class="row">
                    <div class="col-3">
                        <div>
                            <p><i class="fas fa-truck fa-flip-horizontal"></i></p>
                        </div>
                    </div>
                    <div class="col-9">
                        <h3>Free Shiping</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus </p>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="row">
                    <div class="col-3">
                        <div>
                            <p><i class="fas fa-dollar-sign"></i></p>
                        </div>
                    </div>
                    <div class="col-9">
                        <h3>Money Back Gueranty</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus </p>
                    </div>

                </div>
            </div>
            <div class="col-sm-4">
                <div class="row">
                    <div class="col-3">
                        <div>
                            <p><i class="fas fa-globe"></i></p>
                        </div>
                    </div>
                    <div class="col-9">
                        <h3>Online Support 24/7</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus </p>
                    </div>

                </div>
            </div>

        </div>

    </div>
</section>