<?php
include_once ($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
?>
<div class="content">
    <div class="container">
        <div class="d-flex justify-content-center h-100">
            <div class="card">
                <div class="card-header">
                    <h3>LOGIN</h3>
                </div>
                <div class="card-body">
                    <form method="post" action="<?=$webroot?>admin/users/login-processor.php" enctype="multipart/form-data">
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                            </div>
                            <input
                                    type="text"
                                    class="form-control"
                                    id="input-user-name"
                                    name="user_name"
                                    value=""
                                    placeholder="username">

                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-key"></i></span>
                            </div>
                            <input
                                    type="password"
                                    class="form-control"
                                    id="input-password"
                                    name="password"
                                    value=""
                                     placeholder="password">
                        </div>
                        <div class="row align-items-center remember">
                            <input type="checkbox">Remember Me
                        </div>
                        <div class="form-group">

                            <button type="submit" class="btn float-right login_btn">Login</button>
                        </div>
                    </form>
                </div>
                <div class="card-footer">
                    <div class="d-flex justify-content-center links">
                        Don't have an account?<a href="sign-up.php">Sign Up</a>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="social-login-wrapper">
        <p>Access your account through  your social networks.</p>

        <div class="btn-group">
            <a href="https://accounts.google.com/servicelogin" class="btn btn-social-login btn-md btn-gplus mb-1"><i class="fab fa-google-plus-g"></i><span>Google</span></a>
            <a href="https://www.facebook.com/" class="btn btn-social-login btn-md btn-facebook mb-1"><i class="fab fa-facebook-f"></i><span>Facebook</span></a>
            <a href="https://twitter.com/" class="btn btn-social-login btn-md btn-twitter mb-1"><i class="fab fa-twitter"></i><span>Twitter</span></a>
        </div>
    </div>
</div>
