<div class="container-fluid">
    <div class="raw">
        <div id="product">

            <div class="row">

                <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 align-content-center" id="imgsize">
                    <img src="img/cart2.png" alt="product" class="img-fluid" id="imgres">
                </div>

                <div class="col-lg-3 col-md-12 col-sm-12 protext">
                    <h4 class="display-4">Casual Full Sleeve Top</h4>
                </div>

                <div class="col-lg-2 col-md-12 col-sm-12 protext fontSizzing">
                    <span>PRICE</span>
                    <hr width="50%">
                    <p class="card-text">$80</p>
                </div>

                <div class="col-lg-1 col-md-12 col-sm-12 protext pt-2 pb-2">
                    <input type="number" value="1" placeholder="QTY" id="Qinput">
                </div>
                <div class="col-lg-3 col-md-12 col-sm-12 protext fontSizzing pb-md-2 pb-sm-2 pb-xs-2" id="fonthov">
                    <span>TOTAL</span>
                    <hr width="50%">
                    <p class="card-text">$80</p>
                </div>


            </div>






        </div>


    </div>
</div>