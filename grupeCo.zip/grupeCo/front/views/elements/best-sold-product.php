<?php
use App\Products;
$_products=new Products();
$a=$_products->bestSoldPr();
/*var_dump($a);*/
$datalimit = 3;
$product = array_chunk($a,$datalimit,true);
/*var_dump($product);*/

/*var_dump($product);*/
?>

<section id="best-sold">
    <div class="container">
        <h3>Best sold product</h3>
    <?php foreach ($product as $product):?>
        <div class="card-deck">
          <?php foreach ($product as $products): ?>
                <div class="card">
                    <a href="product-details.php"> <img src="<?= $webroot;$a = $a++; ?>/uploads/<?= $products['picture']; ?>"
                                                        class="card-img-top" alt="..."></a>
                    <div class="card-body">
                        <h5 class="card-title"><a href="product-details.php"><?php echo $products['title']; ?></a></h5>
                        <p class="card-text">This is a longer card with supphdhfdrhrdhorting text below as a natural lead-in to
                            additional content. This content is a dhthfdhlittle bit longer.</p>
                        <p class="card-text">
                            <small class="text-muted">Last updated 3 mins ago dfhdhdhdghfdhfdjhfdrj</small>
                        </p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
    </div>
</section>