<?php
use App\Products;
$_products=new Products();
$products=$_products->index();

?>

<section id="best-selling">

    <div class="container">
        <h3>Best  product</h3>
        <?php
        foreach ($products as $product):

        ?>
        <div class="row row-cols-3 row-cols-md-2">
            <div class="col mb-4">


            <div class="card">

                    <a href="product-details.php"> <img src="<?=$webroot;?>/uploads/<?=$product['picture'];?>" class="card-img-top" alt="..."></a>
                    <div class="card-body">
                        <h5 class="card-title"><a href="product-details.php"><?php $product['title'];?></a></h5>
                        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                        <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                    </div>

                </div>
            <?php
            endforeach;
            ?>
            </div>
    </div>



</section>