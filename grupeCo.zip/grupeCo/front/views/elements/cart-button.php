


<div class="container col-lg-3">
    <button role="button" class="btn btn-outline-primary btn-lg btn-block mt-5"> <a href="<?php echo $webroot;?>/front/public/index.php">CONTINUE SHOPPING</a></button>
    <button type="button" class="btn btn-outline-secondary btn-lg btn-block mb-5"><a href="<?php echo $webroot;?>/front/public/check-out.php">PROCEED</a></button>

</div>