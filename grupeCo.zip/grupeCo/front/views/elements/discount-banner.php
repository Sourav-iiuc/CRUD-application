<div class="card bg-dark text-white" id="banner">
    <img src="img/summer.jpg" class="card-img" alt="...">
    <div class="card-img-overlay">
        <h5 class="card-title">50% off seoson</h5>
        <a href="product-details.html"><p class="card-text">Buy Now.</p> </a>

    </div>
</div>