<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
use App\Product;
$_product=new Product();
$products=$_product->getmore();
?>
<div class="container" id="more-product">
    <h3 style="text-align: center; background-color: #8c8e94; margin:auto;padding: 10px 0px 10px 0px">More Products</h3>
    <div class="row">
        <?php
        foreach ($products as $product):
        ?>
        <div class="col-md-3 mt-2">
            <div class="card-group">
                <div class="card">
                    <img src="<?=$webroot;?>/uploads/<?=$product['picture']?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><?=$product['title'];?></h5>
                        <p class="card-text"><?=$product['description'];?></p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">created At : <?=$product['created_at']?></small>
                        <br>
                        <button class="btn btn-outline-secondary" type="button" href="cart.php?id=<?=$product['id']?>">Add To Cart</button>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>