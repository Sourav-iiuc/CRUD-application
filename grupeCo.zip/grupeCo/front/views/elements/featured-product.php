</body><?php

use App\Brand;

$_brand = new Brand();
$brands = $_brand->getFeatureProducts();

?>
<head>
    <style>
        p{
            margin: 0px;
            padding: 0px;
            font-family: Calibri;
        }
        h5{
            font-family: "Times New Roman";
        }
    </style

</head>
<body>
<div class="container">
    <h3 style="text-align: center; background-color: #8c8e94; margin:auto;padding: 10px">Featured Products</h3>
    <div class="card-group">
        <?php
        foreach ($brands as $brand):

            ?>
            <div class="card">

                <form action="<?php echo $webroot?>front/public/cart/add_to_cart.php" method="post">

                    <img src="<?php echo $webroot?>/uploads/<?php echo $brand['picture']?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $brand['title']?></h5>
                        <p class="card-text"><?php echo $brand['detail']?></p>
                    </div>


                    <div class="form-group">
                        <label for="quantity">Qty</label>
                        <input type="number" value="1" name="qty" />
                    </div>


                    <input class="form-control" type="hidden" value="<?php echo $brand['id'];?>" name="product_id"/>
                    <input class="form-control" type="hidden" value="<?php echo rand()?>" name="user_id"/>
                    <input class="form-control" type="hidden" value="<?php echo $brand['title'];?>" name="product_title"/>
                    <input class="form-control" type="hidden" value="<?php echo $brand['mrp'];?>" name="unit_price"/>
                    <input class="form-control" type="hidden" value="<?php echo $brand['picture'];?>" name="picture"/>



                    <div class="card-footer">
                        <button class="btn btn-outline-success form-control"">Add To Cart</button>
                    </div>





                </form>

            </div>
        <?php
        endforeach;
        ?>

    </div>
</div>
</body>

