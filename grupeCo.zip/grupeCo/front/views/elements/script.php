<!--<script src="js/bootstrap.min.js"></script>
 <script src="js/jquery.js"></script> -->

<script src="js/jquery-3.3.2.slim.min.js"></script>
<script src="js/popper.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>

<script>
    $('.carousel').carousel({
        interval: 1500
    })
</script>