<head>
    <meta charset="UTF-8">
    <title>Ecommerce Project</title>
    <!--adding bootstrap file-->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!--adding fonts css-->
    <link rel="stylesheet" href="css/all.min.css">
    <!-- adding css file-->
    <link rel="stylesheet" href="css/style.css">
</head>