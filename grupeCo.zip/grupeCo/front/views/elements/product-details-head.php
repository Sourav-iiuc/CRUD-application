<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- jQuery -->
    <script src="js/jquery-2.0.0.min.js" type="text/javascript"></script>


    <!-- Bootstrap CSS -->
    <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
    <link rel="stylesheet" href="css/product-details.css" type="text/css">

    <title>This is a product details page</title>
</head>