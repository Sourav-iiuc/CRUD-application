<?php
include_once ($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
?>
<section id="createAnAccount" class="mt-5">
    <div class="container">
        <div class="row">
            <div class="col-7 offset-2">
                <h4 class="createAccount">CREATE AN ACCOUNT</h4>
                <form method="post" action="<?=$webroot?>admin/users/sign-up.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="input-user-name">User Name</label>
                        <input
                                type="text"
                                class="form-control"
                                id="input-user-name"
                                name="user_name"
                                value="">
                    </div>
                    <div class="form-group">
                        <label for="input-password">Password</label>
                        <input
                                type="password"
                                class="form-control"
                                id="input-password"
                                name="password"
                                value="">
                    </div>

                    <div class="form-group">
                        <label for="input-full-name">Full Name</label>
                        <input
                                type="text"
                                class="form-control"
                                id="input-full-name"
                                name="full_name"
                                value="">
                    </div>
                    <div class="form-group">
                        <label for="input-email">Email</label>
                        <input
                                type="email"
                                class="form-control"
                                id="input-email"
                                name="email"
                                value="">
                    </div>
                    <div class="form-group">
                        <label for="input-phone-number">Phone Number</label>
                        <input
                                type="tel"
                                class="form-control"
                                id="input-phone-number"
                                name="phone_number"
                                value="">
                    </div>


                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
