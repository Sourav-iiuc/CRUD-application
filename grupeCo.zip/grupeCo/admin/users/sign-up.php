<?php
include_once ($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');

use App\users;

$data = $_POST;

function is_empty($value){
    if($value == ''){
        return true;
    }else{
        return false;
    }
}

if(is_empty($data['user_name'])){
    session_start();
    $_SESSION['message'] = "User name can't be empty. Please enter user name";
    header("location:".$webroot."front/public/sign-up.php");
}
else {
        $_user = new users();
        $_user->signup($data);
}
?>