<?php
include_once ($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');

use App\users;

$_user = new users();
$_user->delete();



?>


