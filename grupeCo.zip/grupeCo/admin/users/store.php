<?php

include_once ($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');


use App\users;


$data = $_POST;

function is_empty($value){
    if($value == ''){
        return true;
    }
    else{
        return false;
    }
}

if(is_empty($data['full_name'])){
    session_start();
    $_SESSION['message'] = "Full Name can't be empty.Please enter Full Name.";
    header("location:create.php");
}
else {
    $_user = new users();
    $_user->store($data);
}
?>