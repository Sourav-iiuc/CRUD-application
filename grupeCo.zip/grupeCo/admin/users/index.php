<?php
include_once ($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
use App\users;
$_user = new users();
$users = $_user->index();
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>User Index</title>
</head>
<body>
<header>
    <div class="container-fluid">
        <div class="row bg-dark">
            <div class="col-10">
                <nav class="navbar navbar-expand-lg navbar-dark" id="top">
                    <a class="navbar-brand" href="../dashboard/dashboard.php"><img src="<?=$webroot;?>/uploads/logo.png" width="250" height="50" /></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="#">Username</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="../../front/public/index.php">back to front</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="../dashboard/logout.php">logout</a>
                            </li>
                    </div>
                </nav>
            </div>
            <div class="col-2">
                <button type="button" class="btn btn-warning mt-1 ml-5"> <a class="nav-item nav-link" href="../dashboard/logout.php" style="color: #fff">logout</a></button>
            </div>
        </div>
    </div>
</header>

<section>
    <div class="container">
        <p class="text-center text-success font-weight-bold mt-2">
            <?php
            echo $_SESSION['message'];
            $_SESSION['message']="";
            ?>
        </p>
    </div>
</section>
<section>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-4">
                <ul class="nav">
                    <li class="nav-item">
                        <a class="nav-link h4" href="../users/create.php">
                            <button type="button" class="btn btn-outline-success">Add An User</button>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="col-2">

            </div>

        </div>
        <div class="row justify-content-center">
            <div class="col-8">
                <table class="table table-responsive table-hover">
                    <thead class="thead-dark">
                    <tr>
                        <th scope="col"> Full Name</th>
                        <th scope="col"> User Name</th>
                        <th scope="col"> Password</th>
                        <th scope="col"> Email</th>
                        <th scope="col"> Phone Number</th>
                        <th scope="col"> Action</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php
                    if(count($users)>0):
                        foreach ($users as $user) :
                            ?>
                            <tr>
                                <td><a href="../users/show.php?id=<?php echo $user['id']?>"><?php echo $user['full_name']?></a>  </td>
                                <td><?php echo $user['user_name']?></td>
                                <td> <?php echo $user['password']?> </td>
                                <td> <?php echo $user['email']?> </td>
                                <td> <?php echo $user['phone_number']?> </td>

                                <td><a href="../users/edit.php?id=<?php echo $user['id']?>">EDIT</a>  |
                                    <a href="../users/delete.php?id=<?php echo $user['id']?>"onclick="return confirm('Are you sure you want to delete')">DELETE</a>
                                </td>
                            </tr>
                        <?php
                        endforeach;
                    else:
                        ?>
                        <tr>
                            <td colspan="2"> No User is Available. <a href="../users/create.php">Click here to add one</a></td>
                        </tr>
                    <?php
                    endif;
                    ?>
                    </tbody>
                </table>

            </div>

        </div>

    </div>
</section>
<footer>
    <div class="container-fluid">
        <div class="row bg-dark">
            <div class="col-10">
                <nav class="navbar navbar-expand-lg navbar-dark" id="top">
                    <a class="navbar-brand" href="##"><img src="<?=$webroot;?>/uploads/logo.png" width="250" height="50" /></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="#">Username</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="../../front/public/index.php">back to front</a>
                            </li>
                    </div>
                </nav>
            </div>
            <div class="col-2">
                <button type="button" class="btn btn-warning mt-1 ml-5"> <a class="nav-item nav-link" href="../dashboard/dashboard.php" style="color: #fff">Back</a></button>
            </div>
        </div>
    </div>
</footer>


<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>