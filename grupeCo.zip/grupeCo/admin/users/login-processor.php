<?php

include_once ($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');

use App\users;


$user_name = $_POST['user_name'];
$password = $_POST['password'];

function is_empty($value){
    if($value == ''){
        return true;
    }
    else{
        return false;
    }
}

if(empty($user_name)|| empty($password)){
    session_start();
    $_SESSION['message'] = "Title can't be empty.Please enter a title.";
    header("location:" . $webroot."front/public/login.php");
}
else {
    $_user = new users();
    $_user->login($user_name,$password);
}
