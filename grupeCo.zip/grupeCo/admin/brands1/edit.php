<?php
$approot =  $_SERVER['DOCUMENT_ROOT'].'/ecommerce/';
$webroot = "http://localhost/ecommerce/";
include_once ($approot.'vendor/autoload.php');
use Bitm\Brand;

$_brand = new Brand();
$brand = $_brand->edit();

?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Home Practise!</title>
</head>
<body>
<section>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-6">
                <form method="post" action="update.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="des">Enter Title</label>
                        <input type="hidden" name="id" value="<?php echo $brand['id'];?>">
                        <input type="text"
                               class="form-control"
                               id="des"
                               aria-describedby="emailHelp"
                               name="title"
                               value="<?php echo $brand['title'];?>"
                               placeholder="Enter title">
                    </div>
                    <div class="form-group">
                        <label for="des">Enter Detail</label>
                        <input type="hidden" name="id" value="<?php echo $brand['id'];?>">
                        <input type="text"
                               class="form-control"
                               id="des"
                               aria-describedby="emailHelp"
                               name="detail"
                               value="<?php echo $brand['detail'];?>"
                               placeholder="Enter title">
                    </div>
                    <div class="form-group form-check">
                        <label for="des" class="form-check-label">
                            <?php
                            if ($brand['is_active']==0)
                            {
                                ?>
                                <input type="checkbox"
                                       class="form-check-label"
                                       id="des"
                                       aria-describedby="emailHelp"
                                       name="is_active"
                                       value="1"
                                       placeholder="Enter is active">
                                <?php
                            }else {
                                ?>
                                <input type="checkbox"
                                       class="form-check-input"
                                       id="des"
                                       aria-describedby="emailHelp"
                                       name="is_active"
                                       value="1"
                                       checked="checked"
                                       placeholder="Enter is active">
                                <?php
                            }
                            ?>
                            Is Active</label>

                    </div>

                    <div class="form-group form-check">
                        <label for="des" class="form-check-label">
                            <?php
                            if ($brand['is_delete']==0)
                            {
                                ?>
                                <input type="checkbox"
                                       class="form-check-label"
                                       id="des"
                                       aria-describedby="emailHelp"
                                       name="is_delete"
                                       value="1">
                                <?php
                            }else {
                                ?>
                                <input type="checkbox"
                                       class="form-check-input"
                                       id="des"
                                       aria-describedby="emailHelp"
                                       name="is_delete"
                                       value="1"
                                       checked="checked">
                                <?php
                            }
                            ?>
                            Is Delete</label>

                    </div>
                    <div class="form-group">
                        <label for="des">Picture</label>
                        <input type="file"
                               class="form-control-file"
                               id="des"
                               aria-describedby="emailHelp"
                               name="picture"
                               value="<?php echo $brand['picture'] ?>">
                        <img src="<?php echo $webroot; ?>uploads/<?php  echo $brand['picture']; ?>">
                        <input type="hidden"
                               name="old_image"
                               value="<?php echo $brand['picture']; ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>