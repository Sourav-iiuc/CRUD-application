<?php
session_start();
$_id = $_GET['id'];
$_is_delete = 0;
//echo $_id;


//Connection To Database
$conn = new PDO("mysql:host=localhost;dbname=practise", "root", "");
// set the PDO error mode to exception
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

//Insert Command
$query = "UPDATE `brands` SET `is_delete` = :is_delete WHERE `brands`.`id` = :id; ";

//Prepare a statement
$stmt= $conn->prepare($query);
$stmt->bindParam(':id', $_id);
$stmt->bindParam(':is_delete', $_is_delete);
$result = $stmt->execute();
var_dump($result);

/*
echo "<pre>";
var_dump($banner);
echo "</pre>";
*/

if($result)
{
    $_SESSION['message'] = "Brand is restored successfully";
}
else
{
    $_SESSION['message'] = "Brand is not restored";
}


header("location:index.php");