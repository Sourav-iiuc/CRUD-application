<?php

$approot =  $_SERVER['DOCUMENT_ROOT'].'/ecommerce/';
$webroot = "http://localhost/ecommerce/";
include_once ($approot.'vendor/autoload.php');
use Bitm\Brand;

$_brand = new Brand();
$brand = $_brand->store();

/*
echo "<pre>";
var_dump($_POST);
echo "</pre>";
*/



