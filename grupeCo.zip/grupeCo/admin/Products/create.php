<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
//include_once($_SERVER['DOCUMENT_ROOT'].'/grupeCo/authenticator.php');
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css" type="text/css">

    <title>Add an product</title>
</head>
<body>
<header>
    <div class="container-fluid">
        <div class="row bg-dark">
            <div class="col-10">
                <nav class="navbar navbar-expand-lg navbar-dark" id="top">
                    <a class="navbar-brand" href="../dashboard/dashboard.php"><img src="<?=$webroot;?>/uploads/logo.png" width="250" height="50" /></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="#">Username</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="../../front/public/index.php">back to front</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="../dashboard/logout.php">logout</a>
                            </li>
                    </div>
                </nav>
            </div>
            <div class="col-2">
                <button type="button" class="btn btn-warning mt-1 ml-5"> <a class="nav-item nav-link" href="../dashboard/logout.php" style="color: #fff">logout</a></button>
            </div>
        </div>
    </div>
</header>
<section>
    <div class="row">
        <div class="col-5">

        </div>
        <div class="col-7">
            <h2 class="text-success"> Add a Product</h2>
        </div>

    </div>
</section>
<section class="mb-2">
    <div class="container">
        <div class="row justify-content-center">

            <div class="col-6">
                <form method="post" action="store.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="title">Product Name</label>
                        <input type="text" class="form-control" id="title" aria-describedby="titlehelp" placeholder="Enter your title" name="title">
                    </div>
                    <div class="form-group">
                        <label for="picture">Picture</label>
                        <input type="file" class="form-control-file" id="picture"  name="picture">
                    </div>
                    <div class="form-group form-check">
                        <label for="is_active" class="form-check-label">
                            <input
                                    type="checkbox"
                                    class="form-check-input"
                                    id="is_active"
                                    name="is_active"
                                    value="1"
                            >
                            Is Active?
                        </label>
                    </div>
                    <div class="form-group form-check">
                        <label for="is_new" class="form-check-label">
                            <input
                                    type="checkbox"
                                    class="form-check-input"
                                    id="is_new"
                                    name="is_new"
                                    value="1"
                            >
                            Is New?
                        </label>
                    </div>
                    <div class="form-group">
                        <label for="product_type" class="form-check-label">Product Type
                        <select class="custom-select mr-sm-2" id="product_type" name="product_type">
                            <option  selected value="Local">Local</option>
                            <option value="Electrical">Electrical</option>
                            <option value="Computer">Computer</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="mrp">Price</label>
                        <input type="text" class="form-control" id="mrp" aria-describedby="mrphelp" placeholder="Enter mrp" name="mrp">
                    </div>
                    <div class="form-group">
                        <label for="short_description">Short_description</label>
                        <textarea class="form-control" id="short_description" rows="2" name="short_description"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="description">description</label>
                        <textarea class="form-control" id="description" rows="3" name="description"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>

</section>


<footer>
    <div class="container-fluid">
        <div class="row bg-dark">
            <div class="col-10">
                <nav class="navbar navbar-expand-lg navbar-dark" id="top">
                    <a class="navbar-brand" href="##"><img src="<?=$webroot;?>/uploads/logo.png" width="250" height="50" /></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="#">Username</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="../../front/public/index.php">back to front</a>
                            </li>
                    </div>
                </nav>
            </div>
            <div class="col-2">
                <button type="button" class="btn btn-warning mt-1 ml-5"> <a class="nav-item nav-link" href="../dashboard/dashboard.php" style="color: #fff">Back</a></button>
            </div>
        </div>
    </div>
</footer>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="../assets/js/jquery.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>
