<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
use App\Product;
$_product=new Product();
$products=$_product->index();
?>
<!doctype html>

<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="../assets/css/bootstrap.min.css" type="text/css">

<title>Product List</title>
</head>
<body>
<header>
    <div class="container-fluid">
        <div class="row bg-dark">
            <div class="col-10">
                <nav class="navbar navbar-expand-lg navbar-dark" id="top">
                    <a class="navbar-brand" href="../dashboard/dashboard.php"><img src="<?=$webroot;?>/uploads/logo.png" width="250" height="50" /></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="#">Username</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="../../front/public/index.php">back to front</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="../dashboard/logout.php">logout</a>
                            </li>
                    </div>
                </nav>
            </div>
            <div class="col-2">
                <button type="button" class="btn btn-warning mt-1 ml-5"> <a class="nav-item nav-link" href="../dashboard/logout.php" style="color: #fff">logout</a></button>
            </div>
        </div>
    </div>
</header>
<section>
    <div class="container">
        <p class="text-center text-success font-weight-bold mt-2">
            <?php
            echo $_SESSION['masssage'];
            $_SESSION['masssage']="";

            ?>

        </p>
    </div>
</section>
<section>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-4">
                <ul class="nav">
                    <li class="nav-item">
                        <strong>
                            <a class="nav-link" href="create.php">Add an product</a>
                        </strong>
                    </li>
                    <li class="nav-item">
                        <strong>
                            <a class="nav-link" href="trash_index.php">Recycle Bin</a>
                        </strong>
                    </li>
                </ul>
            </div>
        </div>
        <table class="table">
            <thead class="thead-dark">
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Title</th>
                <th scope="col">Image</th>
                <!-- <th scope="col">description</th>
                 <th scope="col">short_description</th>-->
                <th scope="col">status</th>
                <!--                <th scope="col">Password</th>-->
                <th scope="col">MRP</th>
                <th scope="col">action</th>
            </tr>
            </thead>
            <tbody>
            <?php

            foreach ($products as $product):


                ?>
                <tr>
                    <td><?= $product['id'] ; ?> </td>
                    <td>
                        <a href="show.php?id=<?= $product['id'];?>"><?= $product['title'] ; ?></a>
                    </td>
                    <td>
                        <img src="../../uploads/<?=$product['picture'];?>" width="100px" height="100px"/>
                    </td>
                    <!--<td><?/*= $product['description'] ; */?></td>
                <td><?/*= $product['short_description'] ; */?></td>-->
                    <td class="font-weight-bold text-success">
                        <?php
                        echo($product['is_active'])?'Active':'Inactive';
                        ?>
                    </td>
                    <td>
                        <?=$product['mrp'];?> tk
                    </td>
                    <td>
                        <a href="edit.php?id=<?=$product['id']?>">Edit</a>
                        |
                        <a href="delete.php?id=<?=$product['id']?>" >Delete</a>
                        |
                        <a href="trash.php?id=<?=$product['id']?>" >Trash</a>
                    </td>
                </tr>
            <?php
            endforeach;
            ?>
            </tbody>
        </table>
    </div>

</section>

<footer>
    <div class="container-fluid">
        <div class="row bg-dark">
            <div class="col-10">
                <nav class="navbar navbar-expand-lg navbar-dark" id="top">
                    <a class="navbar-brand" href="##"><img src="<?=$webroot;?>/uploads/logo.png" width="250" height="50" /></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="#">Username</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="../../front/public/index.php">back to front</a>
                            </li>
                    </div>
                </nav>
            </div>
            <div class="col-2">
                <button type="button" class="btn btn-warning mt-1 ml-5"> <a class="nav-item nav-link" href="../dashboard/dashboard.php" style="color: #fff">Back</a></button>
            </div>
        </div>
    </div>
</footer>


<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="../assets/js/jquery.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>