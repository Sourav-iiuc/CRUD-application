<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
use App\Product;
$_product=new Product();
$products=$_product->restore();
?>