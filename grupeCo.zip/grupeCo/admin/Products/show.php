<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
use App\Product;
$_product=new Product();
$products=$_product->show();
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css" type="text/css">

    <title>Add an Admin</title>
</head>
<body>
<header>
    <div class="container-fluid">
        <div class="row bg-dark">
            <div class="col-10">
                <nav class="navbar navbar-expand-lg navbar-dark" id="top">
                    <a class="navbar-brand" href="../dashboard/dashboard.php"><img src="<?=$webroot;?>/uploads/logo.png" width="250" height="50" /></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="#">Username</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="../../front/public/index.php">back to front</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="../dashboard/logout.php">logout</a>
                            </li>
                    </div>
                </nav>
            </div>
            <div class="col-2">
                <button type="button" class="btn btn-warning mt-1 ml-5"> <a class="nav-item nav-link" href="../dashboard/logout.php" style="color: #fff">logout</a></button>
            </div>
        </div>
    </div>
</header>
<section>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-5">
                <dl>
                    <dt>ID</dt>
                    <dd><?= $products['id']?></dd>

                    <dt>Name</dt>
                    <dd><?= $products['title']?></dd>

                    <dt>description</dt>
                    <dd><?= $products['description']?></dd>
                    <dt>short_description</dt>
                    <dd><?= $products['short_description']?></dd>
                    <dt>Picture</dt>
                    <dd>
                        <?= $products['picture']?>
                        <img src="../../uploads/<?= $products['picture']?>" />
                    </dd>
                    <dt>is active</dt>
                    <dd>
                        <p class="text-success font-weight-bold">
                            <?php
                            /*                            if($product['is_active']==1){
                                                            echo "Active";
                                                        }else{
                                                            echo "Inactive";
                                                        }*/
                            echo($products['is_active'])?'Active':'Inactive';

                            ?>
                        </p>
                    </dd>

                    <dd>
                        <?= $products['mrp']?>
                    </dd>
                </dl>
            </div>
        </div>
    </div>
</section>
<footer>
    <div class="container-fluid">
        <div class="row bg-dark">
            <div class="col-10">
                <nav class="navbar navbar-expand-lg navbar-dark" id="top">
                    <a class="navbar-brand" href="##"><img src="<?=$webroot;?>/uploads/logo.png" width="250" height="50" /></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="#">Username</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="../../front/public/index.php">back to front</a>
                            </li>
                    </div>
                </nav>
            </div>
            <div class="col-2">
                <button type="button" class="btn btn-warning mt-1 ml-5"> <a class="nav-item nav-link" href="../dashboard/dashboard.php" style="color: #fff">Back</a></button>
            </div>
        </div>
    </div>
</footer>
