<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
use App\Product;
$_product=new Product();
$products=$_product->index();
?>
<!doctype html>

<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="../assets/css/bootstrap.min.css" type="text/css">

<title>Product List</title>
</head>
<body>

<section>
    <div class="container">
        <p class="text-center text-success font-weight-bold mt-2">
            <?php
            echo $_SESSION['masssage'];
            $_SESSION['masssage']="";

            ?>

        </p>
    </div>
</section>
<section>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-4">
                <ul class="nav">
                    <li class="nav-item">
                        <strong>
                            <a class="nav-link" href="../Products/create.php">Add an product</a>
                        </strong>
                    </li>
                    <li class="nav-item">
                        <strong>
                            <a class="nav-link" href="../Products/trash_index.php">Recycle Bin</a>
                        </strong>
                    </li>
                </ul>
            </div>
        </div>
        <table class="table">
            <thead class="thead-dark">
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Title</th>
                <th scope="col">Image</th>
                <!-- <th scope="col">description</th>
                 <th scope="col">short_description</th>-->
                <th scope="col">status</th>
                <!--                <th scope="col">Password</th>-->
                <th scope="col">MRP</th>
                <th scope="col">action</th>
            </tr>
            </thead>
            <tbody>
            <?php

            foreach ($products as $product):


                ?>
                <tr>
                    <td><?= $product['id'] ; ?> </td>
                    <td>
                        <a href="../Products/show.php?id=<?= $product['id'];?>"><?= $product['title'] ; ?></a>
                    </td>
                    <td>
                        <img src="../../uploads/<?=$product['picture'];?>" width="100px" height="100px"/>
                    </td>
                    <!--<td><?/*= $product['description'] ; */?></td>
                <td><?/*= $product['short_description'] ; */?></td>-->
                    <td class="font-weight-bold text-success">
                        <?php
                        echo($product['is_active'])?'Active':'Inactive';
                        ?>
                    </td>
                    <td>
                        <?=$product['mrp'];?> tk
                    </td>
                    <td>
                        <a href="../Products/edit.php?id=<?=$product['id']?>">Edit</a>
                        |
                        <a href="../Products/delete.php?id=<?=$product['id']?>" >Delete</a>
                        |
                        <a href="../Products/trash.php?id=<?=$product['id']?>" >Trash</a>
                    </td>
                </tr>
            <?php
            endforeach;
            ?>
            </tbody>
        </table>
    </div>

</section>



<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="../assets/js/jquery.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>