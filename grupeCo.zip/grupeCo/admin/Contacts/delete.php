<?php
include_once ($approot.'vendor/autoload.php');
use App\Contact;
$_contact=new Contact();
$contacts=$_contact->delete();
?>


