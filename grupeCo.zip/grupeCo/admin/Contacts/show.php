<?php
$approot=$_SERVER['DOCUMENT_ROOT']."/final_project/ecommerce/";
$webroot='http://localhost/final_project/ecommerce/';
include_once ($approot.'vendor/autoload.php');
use App\Contact;
$_contact=new Contact();
$contacts=$_contact->show();

?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">

    <title>Add an Admin</title>
</head>
<body>
<section>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-5">
                <dl>
                    <dt>ID</dt>
                    <dd><?= $contacts['id']?></dd>

                    <dt>Name</dt>
                    <dd><?= $contacts['name']?></dd>
                    <dt>Email</dt>
                    <dd><?= $contacts['email']?></dd>
                    <dt>Subject</dt>
                    <dd><?= $contacts['subject']?></dd>
                    <dt>Comment</dt>
                    <dd><?= $contacts['comment']?></dd>
                </dl>
            </div>
        </div>
    </div>

</section>



<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="../js/jquery.js"></script>
<script src="../js/bootstrap.bundle.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</body>
</html>
