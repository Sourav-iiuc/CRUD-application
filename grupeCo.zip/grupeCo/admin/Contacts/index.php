<?php
$approot=$_SERVER['DOCUMENT_ROOT']."/final_project/ecommerce/";
$webroot='http://localhost/final_project/ecommerce/';
include_once ($approot.'vendor/autoload.php');
use App\Contact;
$_contact=new Contact();
$contacts=$_contact->index();
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">

    <title>Admin List</title>
</head>
<body>
<section>
    <div class="container">
        <p class="text-center text-success font-weight-bold mt-2">
            <?php
                echo $_SESSION['masssage'];
                $_SESSION['masssage']="";

            ?>

        </p>
    </div>
</section>

<section>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-4">
                <ul class="nav">
                    <li class="nav-item">

                           <strong><a class="nav-link" href="create.php">Add an contact</a></strong>


                    </li>
                    <li class="nav-item">

                        <strong><a class="nav-link" href="trash_index.php">Bin</a></strong>


                    </li>
                </ul>
            </div>
        </div>
        <table class="table">
            <thead class="thead-dark">
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Subject</th>
<!--                <th scope="col">Password</th>-->
                <th scope="col">action</th>
            </tr>
            </thead>
            <tbody>
            <?php

            foreach ($contacts as $contact):


            ?>
            <tr>
                <td><?= $contact['id'] ; ?> </td>
                <td>
                    <a href="show.php?id=<?= $contact['id'];?>"><?= $contact['name'] ; ?></a>
                </td>
                <td><?= $contact['email'] ; ?></td>
                <td><?= $contact['subject'] ; ?></td>
<!--                <td>--><?//= $contact['comment'] ; ?><!--</td>-->
                <td>
                    <a href="edit.php?id=<?=$contact['id']?>">Edit</a>
                    |
                    <a href="delete.php?id=<?=$contact['id']?>" >Delete</a>
                </td>
            </tr>
            <?php
            endforeach;
            ?>
            </tbody>
        </table>
    </div>

</section>



<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="../js/jquery.js"></script>
<script src="../js/bootstrap.bundle.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</body>

