<?php
$_id=$_GET['id'];
//connecting DB
$conn=new PDO(
    "mysql:host=localhost;
    dbname=ecommerce",
    "root",
    ""
);
// set the PDO error mode to exception
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$query = "SELECT * FROM `contacts` WHERE id = :id ";
$stmt = $conn->prepare($query);
$stmt->bindParam(':id',$_id);
$result = $stmt->execute();
$contact = $stmt->fetch();
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">

    <title>Add an Admin</title>
</head>
<body>
<section>
    <div class="container">
        <div class="row justify-content-center">

            <div class="col-6">
                <form method="post" action="update.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="id">Id</label>
                        <input type="text" class="form-control" id="id" aria-describedby="idhelp" placeholder="Enter your id" name="id" value="<?=$contact['id']?>">
                    </div>
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" aria-describedby="namehelp" placeholder="Enter your name" name="name" value="<?=$contact['name']?>">
                    </div>
                    <div class="form-group">
                        <label for="email">Email address</label>
                        <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email" name="email" value="<?=$contact['email']?>">
                    </div>
                    <div class="form-group">
                        <label for="subject">subject</label>
                        <input type="text" class="form-control" id="subject" aria-describedby="numberHelp" placeholder="Enter your number" name="subject" value="<?=$contact['subject']?>">
                    </div>
                    <div class="form-group">
                        <label for="comment">Password</label>
                        <input type="text" class="form-control" id="comment" placeholder="Password" name="comment" value="<?=$contact['comment']?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>

</section>





<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="../js/jquery.js"></script>
<script src="../js/bootstrap.bundle.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</body>
</html>