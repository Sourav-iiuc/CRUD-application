<?php
$approot=$_SERVER['DOCUMENT_ROOT']."/final_project/ecommerce/";
$webroot='http://localhost/final_project/ecommerce/';
include_once ($approot.'vendor/autoload.php');
use App\Contact;
$_contact=new Contact();
$contacts=$_contact->store();
?>
