<?php
session_start();
// defining variable according to the name field of form
$_id=$_POST['id'];
$_name=$_POST['name'];
$_email=$_POST['email'];
$_comment=$_POST['comment'];
$_subject=$_POST['subject'];


//connection to DB

$conn=new PDO(
    "mysql:host=localhost;
    dbname=ecommerce",
    "root",
    ""
);
//check error
$conn->setAttribute(
    PDO::ATTR_ERRMODE,
    PDO::ERRMODE_EXCEPTION
);
$query="UPDATE `contacts` SET `name`=:name,`email`=:email,`comment`=:comment,`subject`=:subject WHERE `contacts`.`id`=:id";
$stmt=$conn->prepare($query);

$stmt->bindParam(":id",$_id);
$stmt->bindParam(":name",$_name);
$stmt->bindParam(":email",$_email);
$stmt->bindParam(":comment",$_comment);
$stmt->bindParam(":subject",$_subject);
$result=$stmt->execute();
if($result){
    $_SESSION['massage']="Admin Edited Successfully.";
}else{
    $_SESSION['massage']="Sorry I couldn't Edit contact. Please Try again.";
}

header('location:index.php');



?>
