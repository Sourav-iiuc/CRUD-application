<?php
$approot = $_SERVER['DOCUMENT_ROOT'].'/grupeCo/';
$webroot = 'http://localhost/grupeCo';
include_once($approot.'vendor/autoload.php');

use App\Product;

$_product = new Product();
$_product->trash();