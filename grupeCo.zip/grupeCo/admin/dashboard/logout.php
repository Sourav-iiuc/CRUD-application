<?php
session_start();
$_SESSION['is_authenticated']=false;
header('location:localhost/grupeCo/index.php');
