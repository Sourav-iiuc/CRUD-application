<?php
include_once ($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
?>
<!doctype html>
<html lang="en">
<head>
    <title>
        This is Dashboard Page
    </title>
    <link rel="stylesheet" type="text/css" href="<?=$webroot;?>/admin/assets/css/dashboard.css">
</head>
<body>
<header>
    <div class="container-fluid">
        <div class="row bg-dark">
            <div class="col-10">
                <nav class="navbar navbar-expand-lg navbar-dark" id="top">
                    <a class="navbar-brand" href="dashboard.php"><img src="<?=$webroot;?>/uploads/logo.png" width="250" height="50" /></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="#">Username</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="../../front/public/index.php">back to front</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="logout.php">logout</a>
                            </li>
                    </div>
                </nav>
            </div>
            <div class="col-2">
                <button type="button" class="btn btn-warning mt-1 ml-5"> <a class="nav-item nav-link" href="logout.php" style="color: #fff">logout</a></button>
            </div>
        </div>
    </div>
</header>
<section>
    <div class="row">
        <div class="col-2 bg-dark" style="height:">
            <div class="nav flex-column nav-pills bg-dark" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                <a class="nav-link active" id="v-pills-admin-tab" data-toggle="pill" href="#v-pills-admin" role="tab" aria-controls="v-pills-admin" aria-selected="true">Admin</a>
                <a class="nav-link" id="v-pills-banner-tab" data-toggle="pill" href="#v-pills-banner" role="tab" aria-controls="v-pills-banner" aria-selected="false">Banner</a>
                <a class="nav-link" id="v-pills-products-tab" data-toggle="pill" href="#v-pills-products" role="tab" aria-controls="v-pills-products" aria-selected="false">Products</a>
                <a class="nav-link" id="v-pills-users-tab" data-toggle="pill" href="#v-pills-users" role="tab" aria-controls="v-pills-users" aria-selected="false">Users</a>
               <!-- <a class="nav-link" id="v-pills-subscriber-tab" data-toggle="pill" href="#v-pills-subscriber" role="tab" aria-controls="v-pills-subscriber" aria-selected="false">Users</a>-->
            </div>
        </div>
        <div class="col-10 ">
            <div class="tab-content" id="v-pills-tabContent">
                <div class="tab-pane fade show active" id="v-pills-admin" role="tabpanel" aria-labelledby="v-pills-admin-tab">
                    <?php
                    include_once ('../Admins/index1.php');
                    ?>
                </div>
                <div class="tab-pane fade" id="v-pills-banner" role="tabpanel" aria-labelledby="v-pills-banner-tab">
                    <?php
                    include_once ('../Banners/index1.php');
                    ?>
                </div>
                <div class="tab-pane fade" id="v-pills-products" role="tabpanel" aria-labelledby="v-pills-products-tab">
                    <?php
                    include_once ('../Products/index1.php');
                    ?>
                </div>
                <div class="tab-pane fade" id="v-pills-users" role="tabpanel" aria-labelledby="v-pills-users-tab">
                    <?php
                    include_once ('../users/index1.php');
                    ?>
                </div>
               <!-- <div class="tab-pane fade" id="v-pills-subscriber" role="tabpanel" aria-labelledby="v-pills-subscriber-tab">
                    <?php
/*                    include_once ('../subscriber/index1.php');
                    */?>
                </div>-->
            </div>
        </div>
    </div>
</section>
<footer>
    <div class="container-fluid">
        <div class="row bg-dark">
            <div class="col-10">
                <nav class="navbar navbar-expand-lg navbar-dark" id="top">
                    <a class="navbar-brand" href="##"><img src="<?=$webroot;?>/uploads/logo.png" width="250" height="50" /></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="#">Username</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-item nav-link" href="../../front/public/index.php">back to front</a>
                            </li>
                    </div>
                </nav>
            </div>
            <div class="col-2">
                <button type="button" class="btn btn-warning mt-1 ml-5"> <a class="nav-item nav-link" href="../dashboard/dashboard.php" style="color: #fff">Back</a></button>
            </div>
        </div>
    </div>
</footer>
</body>
</html>