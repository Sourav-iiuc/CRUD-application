<?php

include_once( $_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
use App\Banner;

$data = $_POST;
$_banner = new Banner();
$banner = $_banner->update($data);