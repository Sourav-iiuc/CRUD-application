<?php
include_once( $_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
use App\Banner;

$_banner = new Banner();
$banners = $_banner->index();



/*
  echo "<pre>";
var_dump($banners);
echo "</pre>";
 */
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Index Page</title>
  </head>
  <body>
  <section>
      <div class="container">
          <p class="text-center text-success font-weight-bold mt-3">
              <?php
              echo $_SESSION['message'];
              $_SESSION['message']= "";
              ?>

          </p>
      </div>
  </section>
    <section>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-4">
                    <ul class="nav">
                        <li class="nav-item">
                            <strong><a class="nav-link " href="create.php">Add an item</a></strong>
                        </li>
                        <li class="nav-item">
                            <strong><a class="nav-link " href="trash_index.php">All trashed items</a></strong>
                        </li>
                    </ul>

                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-6">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th scope="col">Title</th>
                            <th scope="col">Image</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        if(count($banners)>0):
                        foreach ($banners as $banner):
                        ?>
                        <tr>
                            <td><a href="show.php?id=<?php echo $banner['id']; ?>"><?php echo $banner['title'];?></a></td>
                            <td><img src="<?php echo $webroot; ?>uploads/<?php  echo $banner['picture']; ?>"
                                height="100" width="100"
                                ></td>
                            <td><?php  echo ($banner['is_active']?'Active':'Deactive');?></td>
                            <td>
                                <a href="edit.php?id=<?php echo  $banner['id']?>">Edit</a> |
                               <!-- <a href="delete.php?id=<?php /*echo $banner['id'];*/?>" onclick="return confirm('Are you want to delete?')"> Delete</a>|-->
                                <a href="trash.php?id=<?php echo $banner['id'];?>" onclick="return confirm('Are you want to trash?')"> Trash</a>
                            </td>
                        </tr>
                        <?php
                        endforeach;
                        else:
                            ?>
                        </tbody>
                        <tr>
                            <a colspan="2">No banner is available.</a> <a href="create.php">Click here to add one</a></td>
                        </tr>
                        <?php endif;
                        ?>
                    </table>

                </div>
            </div>

        </div>
    </section>




    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>