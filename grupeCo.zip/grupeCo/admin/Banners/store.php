<?php

include_once( $_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
use App\Banner;


$data = $_POST;

//Validate Title
function is_empty($value)
{
    if ($value == '')
    {
        return true;
    }
    else{
        return false;
    }
}
if (is_empty($data['title']))
{
    session_start();
    $_SESSION['message']='Title can not be empty . Please enter a title';
    header("location:create.php");
}
else{
    $_banner = new Banner();
    $banner = $_banner->store($data);
}


/*
echo "<pre>";
var_dump($_POST);
echo "</pre>";
*/



