<?php
include_once( $_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
use App\Banner;


$_id = $_GET['id'];
$_banner = new Banner();
$banner = $_banner->restore($_id);