<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
use App\admin;
$_admin=new Admin();
$admins=$_admin->index();
?>


<!--<section class="mt-5">
    <div class="container">
        <p class="text-center text-success font-weight-bold mt-2">
            <?php
/*            echo $_SESSION['masssage'];
            $_SESSION['masssage']="";

            */?>

        </p>
    </div>
</section>-->

<section>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-4">
                <ul class="nav">
                    <li class="nav-item">
                        <h4>
                            <a class="nav-link" href="../Admins/create.php">Add an admin</a>
                        </h4>
                    </li>
                </ul>
            </div>
        </div>
        <table class="table">
            <thead class="thead-dark">
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Phone</th>
                <!--                <th scope="col">Password</th>-->
                <th scope="col">action</th>
            </tr>
            </thead>
            <tbody>
            <?php

            foreach ($admins as $admin):


                ?>
                <tr>
                    <td><?= $admin['id'] ; ?> </td>
                    <td>
                        <a href="../Admins/show.php?id=<?= $admin['id'];?>"><?= $admin['name'] ; ?></a>
                    </td>
                    <td><?= $admin['email'] ; ?></td>
                    <td><?= $admin['phone'] ; ?></td>
                    <!--                <td>--><?//= $admin['password'] ; ?><!--</td>-->
                    <td>
                        <a href="../Admins/edit.php?id=<?=$admin['id']?>">Edit</a>
                        |
                        <a href="../Admins/delete.php?id=<?=$admin['id']?>" >Delete</a>
                    </td>
                </tr>
            <?php
            endforeach;
            ?>
            </tbody>
        </table>
    </div>

</section>
