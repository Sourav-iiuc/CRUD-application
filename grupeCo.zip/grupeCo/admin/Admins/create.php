<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
?><!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css" type="text/css">

    <title>Add an Admin</title>
</head>
<body>
<header>
    <div class="container-fluid">
        <div class="row bg-dark">



            <nav class="navbar navbar-expand-lg navbar-dark" id="top">
                <a class="navbar-brand" href="../dashboard/dashboard.php"><img src="../../uploads/logo.png" width="250" height="50" /></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-item nav-link" href="#">Username</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-item nav-link" href="../../front/public/index.php">back to front</a>
                        </li>
                </div>
            </nav>
        </div>
    </div>
</header>
<section class="mt-5">
    <div class="container">
        <div class="row justify-content-center">

            <div class="col-6">
                <form method="post" action="store.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" aria-describedby="namehelp" placeholder="Enter your name" name="name">
                    </div>
                    <div class="form-group">
                        <label for="email">Email address</label>
                        <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email" name="email">
                    </div>
                    <div class="form-group">
                        <label for="phone">phone</label>
                        <input type="tel" class="form-control" id="phone" aria-describedby="numberHelp" placeholder="Enter your number" name="phone">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" placeholder="Password" name="password">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>

</section>





<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="../assets/js/jquery.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>