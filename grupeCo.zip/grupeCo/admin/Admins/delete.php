<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
use App\admin;
$_admin=new Admin();
$admins=$_admin->delete();
?>

