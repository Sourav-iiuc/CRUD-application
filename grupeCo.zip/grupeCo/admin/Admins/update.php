<?php
session_start();
include_once($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
// defining variable according to the name field of form
$_id=$_POST['id'];
$_name=$_POST['name'];
$_email=$_POST['email'];
$_password=$_POST['password'];
$_phone=$_POST['phone'];


//connection to DB

$conn=new PDO(
    "mysql:host=localhost;
    dbname=ecommerce",
    "root",
    ""
);
//check error
$conn->setAttribute(
    PDO::ATTR_ERRMODE,
    PDO::ERRMODE_EXCEPTION
);
$query="UPDATE `admins` SET `name`=:name,`email`=:email,`password`=:password,`phone`=:phone WHERE `admins`.`id`=:id";
$stmt=$conn->prepare($query);

$stmt->bindParam(":id",$_id);
$stmt->bindParam(":name",$_name);
$stmt->bindParam(":email",$_email);
$stmt->bindParam(":password",$_password);
$stmt->bindParam(":phone",$_phone);
$result=$stmt->execute();
if($result){
    $_SESSION['massage']="Admin Edited Successfully.";
}else{
    $_SESSION['massage']="Sorry I couldn't Edit admin. Please Try again.";
}

header('location:index.php');



?>
