<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
use App\admin;
$admin_new=new Admin();
$admins=$admin_new->show_new();




?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">

    <title>Add an Admin</title>
</head>
<body>
<header>
    <div class="container-fluid">
        <div class="row bg-dark">



            <nav class="navbar navbar-expand-lg navbar-dark" id="top">
                <a class="navbar-brand" href="dashboard.php"><img src="../../uploads/logo22.png" width="250" height="50" /></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-item nav-link" href="#">Username</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-item nav-link" href="../../front/public/index.php">back to front</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-item nav-link" href="logout.php">logout</a>
                        </li>
                </div>
            </nav>
        </div>
    </div>
</header>
<section class="mt-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-5">
                <dl>
                    <dt>ID</dt>
                    <dd><?= $admins['id'] ?></dd>

                    <dt>Name</dt>
                    <dd><?= $admins['name'] ?></dd>
                    <dt>Email</dt>
                    <dd><?= $admins['email'] ?></dd>
                    <dt>Phone</dt>
                    <dd><?= $admins['phone'] ?></dd>
                </dl>
            </div>
        </div>
    </div>

</section>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="../js/jquery.js"></script>
<script src="../js/bootstrap.bundle.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</body>
</html>
