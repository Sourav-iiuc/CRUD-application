<?php
include_once( $_SERVER['DOCUMENT_ROOT'].'/grupeCo/config.php');
use App\Brand;


$_id = $_GET['id'];
$_brand = new Brand();
$brand = $_brand->trash($_id);