<?php
/**
 * Created by PhpStorm.
 * User: PHP
 * Date: 11/26/2019
 * Time: 3:15 PM
 */

namespace Bitm;
use PDO;


class Brand
{
    public $conn = null;

    public function __construct()
    {
        //Connection To Database
        $this->conn = new PDO("mysql:host=localhost;dbname=grupeco", "root", "");
// set the PDO error mode to exception
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    }
    
    public function index()
    {
        session_start();
//Insert Command
        $query = "SELECT * FROM `brands` WHERE is_delete = 0";

//Prepare a statement
        $stmt = $this->conn->prepare($query);
        $result = $stmt->execute();
        $brands = $stmt->fetchAll();
        return $brands;
    }
    
    public function getActiveBrands()
    {
       /* session_start();*/
        $startfrom = 0;
        $total = 5;


//Insert Command
        $query = "SELECT * FROM `brands` WHERE is_active = 1 AND is_delete = 0 LIMIT $startfrom,$total ";

//Prepare a statement
        $stmt= $this->conn->prepare($query);
        $result = $stmt->execute();
        $brands = $stmt->fetchAll();
        return $brands;
    }

    public function store()

    {
        $approot = $_SERVER['DOCUMENT_ROOT'] . '/ecommerce/';
        $webroot = "http://localhost/ecommerce/";
        //Working with image upload
        $file_name = "IMG_" . time() . "_" . $_FILES['picture']['name'];
        $target = $_FILES['picture']['tmp_name'];
        $destination = $approot . 'uploads/' . $file_name;
        $is_file_moved = move_uploaded_file($target, $destination);

        if ($is_file_moved) {
            $_picture = $file_name;
        } else {
            $_picture = null;
        }


        $_title = $_POST['title'];
        $_detail = $_POST['detail'];
//$_is_delete = $_POST['is_delete'];
        if (array_key_exists('is_active', $_POST)) {
            $_is_active = $_POST['is_active'];
        } else {
            $_is_active = 0;
        }


        if (array_key_exists('is_delete', $_POST)) {
            $_is_delete = $_POST['is_delete'];
        } else {
            $_is_delete = 0;
        }
        echo "<pre>";
        print_r($_FILES);
        echo "</pre>";
//echo $_title;
        $_created_at = date('Y-m-d h:i:s', time());

//Insert Command
        $query = "INSERT INTO `brands`(`title` , `detail` ,`picture` , `is_active` , `is_delete`,`created_at`) VALUES (:title , :detail , :picture , :is_active , :is_delete , :created_at)";

//Prepare a statement
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':title', $_title);
        $stmt->bindParam(':detail', $_detail);
        $stmt->bindParam(':picture', $_picture);
        $stmt->bindParam(':is_active', $_is_active);
        $stmt->bindParam(':is_delete', $_is_delete);
        $stmt->bindParam(':created_at', $_created_at);
        $result = $stmt->execute();

//var_dump($result);
        if ($result) {
            $_SESSION['message'] = "Brand is added successfully";
        } else {
            $_SESSION['message'] = "Brand is not added";
        }
        header("location:index.php");

    }

    public function show()
    {
        $webroot = "http://localhost/ecommerce/";
        $_id = $_GET['id'];

//Insert Command
        $query = "SELECT * FROM `brands` WHERE id = :id";

//Prepare a statement
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $_id);
        $result = $stmt->execute();
        $brand = $stmt->fetch();
        return $brand;

        /*
        echo "<pre>";
        var_dump($banner);
        echo "</pre>";
        */
    }

    public function edit()
    {
        $webroot = "http://localhost/ecommerce/";

        $_id = $_GET['id'];

//echo $_id;
        
//Insert Command
        $query = "SELECT * FROM `brands` WHERE id = :id";

//Prepare a statement
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $_id);
        $result = $stmt->execute();
        $brand = $stmt->fetch();
        return $brand;

        /*
        echo "<pre>";
        var_dump($banner);
        echo "</pre>";
        */
    }

    public function update()
    {
        $approot = $_SERVER['DOCUMENT_ROOT'] . '/ecommerce/';
        $webroot = "http://localhost/ecommerce/";
        session_start();

//Working with image upload
        if ($_FILES['picture']['name'] != "") {
            $file_name = "IMG_" . time() . "_" . $_FILES['picture']['name'];
            $target = $_FILES['picture']['tmp_name'];
            $destination = $approot . 'uploads/' . $file_name;
            $is_file_moved = move_uploaded_file($target, $destination);

            if ($is_file_moved) {
                $_picture = $file_name;
            } else {
                $_picture = null;
            }

        } else {
            $_picture = $_POST['old_image'];
        }
        /*
        echo "<pre>";
        var_dump($_POST);
        echo "</pre>";
        */
        $_id = $_POST['id'];
        $_title = $_POST['title'];
        $_detail = $_POST['detail'];
//$_is_active = $_POST['is_active'];
//echo $_title;
        echo $_id;
        echo $_title;

        if (array_key_exists('is_active', $_POST)) {
            $_is_active = $_POST['is_active'];
        } else {
            $_is_active = 0;
        }

        if (array_key_exists('is_delete', $_POST)) {
            $_is_delete = $_POST['is_deleted'];
        } else {
            $_is_delete = 0;
        }

        $_modified_at = date('Y-m-d h:i:s', time());
//Insert Command
        $query = "UPDATE `brands` SET `title` = :title , `detail` = :detail, `is_active` = :is_active ,`picture` = :picture , `modified_at` = :modified_at WHERE `brands`.`id` = :id; ";

//Prepare a statement
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $_id);
        $stmt->bindParam(':title', $_title);
        $stmt->bindParam(':detail', $_detail);
        $stmt->bindParam(':is_active', $_is_active);
        $stmt->bindParam(':picture', $_picture);
        $stmt->bindParam(':modified_at', $_modified_at);
        $result = $stmt->execute();

        if ($result) {
            $_SESSION['message'] = "Brand is updated successfully";
        } else {
            $_SESSION['message'] = "Brand is not updated";
        }

//var_dump($result);
        header("location:index.php");
    }

    public function delete()
    {
        session_start();
        $_id = $_GET['id'];
//echo $_id;
        
//Insert Command
        $query = "DELETE FROM `brands` WHERE `brands`.`id` = :id";

//Prepare a statement
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $_id);
        $result = $stmt->execute();
        //var_dump($result);

        /*
        echo "<pre>";
        var_dump($banner);
        echo "</pre>";
        */

        if ($result) {
            $_SESSION['message'] = "Brand is deleted successfully";
        } else {
            $_SESSION['message'] = "Brand is not deleted";
        }


        header("location:index.php");
    }

    public function trash($_id)
    {
        session_start();
        $_is_delete = 1;
//echo $_id;

//Insert Command
        $query = "UPDATE `brands` SET `is_delete` = :is_delete WHERE `brands`.`id` = :id; ";

//Prepare a statement
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $_id);
        $stmt->bindParam(':is_delete', $_is_delete);
        $result = $stmt->execute();
        var_dump($result);

        /*
        echo "<pre>";
        var_dump($banner);
        echo "</pre>";
        */

        if ($result) {
            $_SESSION['message'] = "Brand is trashed successfully";
        } else {
            $_SESSION['message'] = "Brand is not trashed";
        }


        header("location:index.php");
    }

    public function trash_index()
    {

        $webroot = "http://localhost/ecommerce/";

//Insert Command
        $query = "SELECT * FROM `brands` WHERE is_delete = 1";

//Prepare a statement
        $stmt = $this->conn->prepare($query);
        $result = $stmt->execute();
        $brands = $stmt->fetchAll();
        return $brands;

    }
}