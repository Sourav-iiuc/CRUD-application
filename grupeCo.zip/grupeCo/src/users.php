<?php


namespace App;
use PDO;


class Users
{
    public $conn=null;
    public function __construct()
    {
//        session_start();
        $this->conn = new PDO("mysql:host=localhost;dbname=grupeco", "root", "");
        // set the PDO error mode to exception
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        /*echo "connect successfully";*/
    }


    public function index(){
        $query ="SELECT * FROM users";

        $stmt = $this->conn->prepare($query);
        $result = $stmt->execute();

        $users = $stmt-> fetchAll();
        return $users;
    }


    public function store(){
        $full_name = $_POST['full_name'];
        $user_name = $_POST['user_name'];
        $_pass = $_POST['password'];
        $_email = $_POST['email'];
        $_phn_numb = $_POST['phone_number'];
        //insert
        $query = "INSERT INTO users (full_name,user_name,password,email,phone_number) VALUES (:full_name,:user_name,:password,:email,:phone_number)";


        //prepare a statement
        $stmt= $this->conn ->prepare($query);
        $stmt->bindParam(':full_name',$full_name);
        $stmt->bindParam(':user_name',$user_name);
        $stmt->bindParam(':password',$_pass);
        $stmt->bindParam(':email',$_email);
        $stmt->bindParam(':phone_number',$_phn_numb);



        $result = $stmt->execute();
        var_dump($result);

        if($result){
            $_SESSION['message']="User is added successfully";

        }
        else{
            $_SESSION['message']="User is not added";
        }
        header("location:index.php");
    }



    public function show(){
        $_id = $_GET['id'];

        $query ="SELECT * FROM users where id= :id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id',$_id);
        $result = $stmt->execute();

        $user = $stmt-> fetch();
        return $user;
    }



    public function edit(){
        $_id = $_GET['id'];

        $query ="SELECT * FROM users where id= :id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id',$_id);
        $result = $stmt->execute();

        $user = $stmt-> fetch();
        return $user;
    }


    public function update(){

        $_id =$_POST['id'];
        $full_name = $_POST['full_name'];
        $user_name = $_POST['user_name'];
        $_pass = $_POST['password'];
        $_email = $_POST['email'];
        $_phn_numb = $_POST['phone_number'];


//insert
        $query = "UPDATE users SET full_name = :full_name,user_name = :user_name,password= :password,email= :email,phone_number= :phone_number WHERE users.id = :id;";


        //prepare a statement
        $stmt= $this->conn ->prepare($query);
        $stmt->bindParam(':id',$_id);
        $stmt->bindParam(':full_name',$full_name);
        $stmt->bindParam(':user_name',$user_name);
        $stmt->bindParam(':password',$_pass);
        $stmt->bindParam(':email',$_email);
        $stmt->bindParam(':phone_number',$_phn_numb);




        $result = $stmt->execute();
        var_dump($result);

        if($result){
            $_SESSION['message']="User is updated successfully";

        }
        else{
            $_SESSION['message']="User is not updated";
        }
        header("location:index.php");
    }


    public function delete(){
        $_id = $_GET['id'];

        $query ="DELETE FROM users WHERE users.id = :id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id',$_id);
        $result = $stmt->execute();

        /*$banner = $stmt-> fetch();*/

        var_dump($result);
        if($result){
            $_SESSION['message']="user is deleted successfully";

        }
        else{
            $_SESSION['message']="user is not deleted";
        }
        header("location:index.php");
    }


    public function signup(){
        $full_name = $_POST['full_name'];
        $user_name = $_POST['user_name'];
        $_pass = $_POST['password'];
        $_email = $_POST['email'];
        $_phn_numb = $_POST['phone_number'];
        //insert
        $query = "INSERT INTO users (full_name,user_name,password,email,phone_number) VALUES (:full_name,:user_name,:password,:email,:phone_number)";


        //prepare a statement
        $stmt= $this->conn ->prepare($query);
        $stmt->bindParam(':full_name',$full_name);
        $stmt->bindParam(':user_name',$user_name);
        $stmt->bindParam(':password',$_pass);
        $stmt->bindParam(':email',$_email);
        $stmt->bindParam(':phone_number',$_phn_numb);


        $result = $stmt->execute();
        var_dump($result);

        if($result){
            $_SESSION['message']="User is added successfully";

        }
        else{
            $_SESSION['message']="User is not added";
        }
        header("location:http://localhost/grupeCo/front/public/login.php");
    }


    public function login($user_name, $password){

        $query = "SELECT COUNT(*) AS total FROM `users` WHERE user_name LIKE :user_name AND password LIKE :password";



        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_name',$user_name);
        $stmt->bindParam(':password',$password);
        $result = $stmt->execute();

        $totalfound = $stmt-> fetch();

        if ($totalfound['total'] > 0){


            $_SESSION['is_authenticated'] = true;

            header("location:http://localhost/grupeCo/admin/dashboard/dashboard.php");


        }

        else{

            $_SESSION['is_authenticated'] = false;

            header("location:http://localhost/grupeCo/404.php");

        }


    }

}