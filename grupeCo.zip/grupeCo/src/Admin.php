<?php
/**
 * Created by PhpStorm.
 * User: PHP
 * Date: 11/24/2019
 * Time: 4:04 PM
 */
namespace App;
use PDO;


class Admin
{
    public function index(){
        //session_start();

        $conn=new PDO(
            "mysql:host=localhost;
    dbname=grupeco",
            "root",
            ""
        );
//check error
        $conn->setAttribute(
            PDO::ATTR_ERRMODE,
            PDO::ERRMODE_EXCEPTION
        );

//insert command through making querry
        $query="SELECT * FROM `admins`";

//prepare statement and bind it within DB

        $stmt=$conn->prepare($query);
        $result=$stmt->execute();
//fatch data from DB
        $admins=$stmt->fetchAll();
        return $admins;
    }

    public function store(){
        // defining variable according to the name field of form
        session_start();

        $_name=$_POST['name'];
        $_email=$_POST['email'];
        $_password=$_POST['password'];
        $_phone=$_POST['phone'];

//connection to DB

        $conn=new PDO(
            "mysql:host=localhost;
    dbname=grupeco",
            "root",
            ""
        );
//check error
        $conn->setAttribute(
            PDO::ATTR_ERRMODE,
            PDO::ERRMODE_EXCEPTION
        );

//insert command through making querry
        $query="INSERT INTO `admins`( `name`, `email`, `password`, `phone`, `soft_delete`, `is_draft`, `created_at`, `modified_at`)  VALUES (:name,:email, :password, :phone, NULL, NULL, NULL, NULL)";

//prepare statement and bind it within DB

        $stmt=$conn->prepare($query);
        $stmt->bindParam(":name",$_name);
        $stmt->bindParam(":email",$_email);
        $stmt->bindParam(":password",$_password);
        $stmt->bindParam(":phone",$_phone);

        $result=$stmt->execute();

//successfull massage setting
        if($result){
            $_SESSION['massage']="Admin Added Successfully.";
        }else{
            $_SESSION['massage']="Sorry I couldn't add admin. Please Try again.";
        }

        header('location:index.php');

    }

    public function show_new(){

        $_id=$_GET['id'];
        /*echo $_id;*/
//connecting DB
        $conn=new PDO(
            "mysql:host=localhost;
    dbname=grupeco",
            "root",
            ""
        );
// set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $query = "SELECT * FROM `admins` WHERE `id` = :id ";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id',$_id);
        $result = $stmt->execute();
        $admins = $stmt->fetch();
        return $admins;



    }
    public function delete(){
        session_start();
        $_id=$_GET['id'];
//connection to DB

        $conn=new PDO(
            "mysql:host=localhost;
    dbname=grupeco",
            "root",
            ""
        );
//check error
        $conn->setAttribute(
            PDO::ATTR_ERRMODE,
            PDO::ERRMODE_EXCEPTION
        );
        $query="DELETE FROM `admins` WHERE `id`=:id";
        $stmt=$conn->prepare($query);
        $stmt->bindParam(":id",$_id);
        $result=$stmt->execute();
        if($result){
            $_SESSION['massage']="Admin Deleted Successfully.";
        }else{
            $_SESSION['massage']="Sorry I couldn't Delete admin. Please Try again.";
        }

        header('location:index.php');

    }

}