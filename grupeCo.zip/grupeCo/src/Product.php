<?php
/**
 * Created by PhpStorm.
 * User: showr
 * Date: 12/13/2019
 * Time: 8:14 PM
 */

namespace App;

use PDO;

class Product
{
    public $id = null;
    public $title = null;
    public $detail = null;
    public $promotional_message = null;
    public $conn = null;
    //global construct function
    public function __construct()
    {
        //Connect to Database
        $this->conn = new PDO("mysql:host=localhost;dbname=grupeco", "root", "");
        // set the PDO error mode to exception
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    //upload function for adding and editing pic
    private function upload(){

        $approot = $_SERVER['DOCUMENT_ROOT'].'/grupeCo/';
        $_picture = null;

        if($_FILES['picture']['name'] != ""){
            $file_name = "IMG_".time()."_".$_FILES['picture']['name'];
            $target = $_FILES['picture']['tmp_name'];
            $destination = $approot.'uploads/'.$file_name;
            $is_file_moved = move_uploaded_file($target, $destination);

            if($is_file_moved){
                $_picture = $file_name;
            }
        }else{
            if($_POST['old_image']){
                $_picture = $_POST['old_image'];
            }
        }
        return $_picture;
    }
    public function index(){
    //Insert Command
    $query = "SELECT * FROM `products` WHERE is_deleted = 0";

    //Prepare a statement
    $stmt = $this->conn->prepare($query);

    $result = $stmt->execute();

    $products = $stmt->fetchAll();
    return $products;

}
    public function getnew(){
    //Insert Command
    $query = "SELECT * FROM `products` WHERE is_new = 1 LIMIT 0,3";

    //Prepare a statement
    $stmt = $this->conn->prepare($query);

    $result = $stmt->execute();

    $products = $stmt->fetchAll();
    return $products;

}
    public function getmore(){
    //Insert Command
    $query = "SELECT * FROM `products` WHERE `product_type` = 'other' LIMIT 0,4";

    //Prepare a statement
    $stmt = $this->conn->prepare($query);

    $result = $stmt->execute();

    $products = $stmt->fetchAll();
    return $products;

}
    public function gettranding(){
    //Insert Command
    $query = "SELECT * FROM `products` WHERE `product_type` = 'Electrical' LIMIT 0,4";

    //Prepare a statement
    $stmt = $this->conn->prepare($query);

    $result = $stmt->execute();

    $products = $stmt->fetchAll();
    return $products;

}
    public function show(){
        $_id=$_GET['id'];
        $query = "SELECT * FROM `products` WHERE id = :id ";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id',$_id);
        $result = $stmt->execute();
        $product = $stmt->fetch();
        return $product;

    }
    public function store(){

        $_picture=$this->upload();
        $_mrp=$_POST['mrp'];
        $_title=$_POST['title'];
        $_product_type=$_POST['product_type'];
        $_description=$_POST['description'];
        $_short_description=$_POST['short_description'];
//code for randering is active value
        if(array_key_exists('is_active',$_POST)){
            $_is_active=$_POST['is_active'];
        }else{
            $_is_active=0;
        }
        if(array_key_exists('is_new',$_POST)){
            $_is_new=$_POST['is_new'];
        }else{
            $_is_new=0;
        }


//insert command through making querry
        $query="INSERT INTO `products`( `title`,`picture`,`is_active`,`mrp`,`is_new`,`product_type`,`description`,`short_description`)  VALUES (:title,:picture,:is_active,:mrp,:is_new,:product_type,:description,:short_description)";

//prepare statement and bind it within DB

        $stmt=$this->conn->prepare($query);
        $stmt->bindParam(":title",$_title);
        $stmt->bindParam(":picture",$_picture);
        $stmt->bindParam(":is_active",$_is_active);
        $stmt->bindParam(":mrp",$_mrp);
        $stmt->bindParam(":is_new",$_is_new);
        $stmt->bindParam(":product_type",$_product_type);
        $stmt->bindParam(":description",$_description);
        $stmt->bindParam(":short_description",$_short_description);

        $result=$stmt->execute();

         //successfull massage setting
        if($result){
            $_SESSION['massage']="product Added Successfully.";
        }else{
            $_SESSION['massage']="Sorry I couldn't add product. Please Try again.";
        }

        header('location:index.php');

    }
    public function update(){
        $_id=$_GET['id'];
        $_picture=$this->upload();
        $_mrp=$_POST['mrp'];
        $_title=$_POST['title'];
        $_product_type=$_POST['product_type'];
        $_description=$_POST['description'];
        $_short_description=$_POST['short_description'];
//code for randering is active value
        if(array_key_exists('is_active',$_POST)){
            $_is_active=$_POST['is_active'];
        }else{
            $_is_active=0;
        }
        if(array_key_exists('is_new',$_POST)){
            $_is_new=$_POST['is_new'];
        }else{
            $_is_new=0;
        }

//insert command through making querry
        $query="UPDATE `products` SET `title`=:title,`description` =:description, `is_new` =:is_new, `mrp` = :mrp,`picture`=:picture,`is_active`=:is_active,`product_type`=:product_type,`short_description`=:short_description WHERE `products`.`id` =:id";

//prepare statement and bind it within DB

        $stmt=$this->conn->prepare($query);
        $stmt->bindParam(":id",$_id);
        $stmt->bindParam(":title",$_title);
        $stmt->bindParam(":picture",$_picture);
        $stmt->bindParam(":is_active",$_is_active);
        $stmt->bindParam(":mrp",$_mrp);
        $stmt->bindParam(":is_new",$_is_new);
        $stmt->bindParam(":product_type",$_product_type);
        $stmt->bindParam(":description",$_description);
        $stmt->bindParam(":short_description",$_short_description);

        $result=$stmt->execute();

//successfull massage setting
        if($result){
            $_SESSION['massage']="product Updated Successfully.";
        }else{
            $_SESSION['massage']="Sorry I couldn't Update product. Please Try again.";
        }

        header('location:index.php');

    }
    public function restore(){
        $_id=$_GET['id'];
        $_is_deleted=0;
//connection to DB


        $query="UPDATE `products` SET `is_deleted`=:is_deleted WHERE `products`.`id`=:id";
        $stmt=$this->conn->prepare($query);
        $stmt->bindParam(":id",$_id);
        $stmt->bindParam(":is_deleted",$_is_deleted);
        $result=$stmt->execute();
        if($result){
            $_SESSION['massage']="product Deleted Successfully.";
        }else{
            $_SESSION['massage']="Sorry I couldn't Delete product. Please Try again.";
        }

        header('location:index.php');

    }
    public function delete(){
        $_id=$_GET['id'];
        $query="DELETE FROM `products` WHERE `id`=:id";
        $stmt=$this->conn->prepare($query);
        $stmt->bindParam(":id",$_id);
        $result=$stmt->execute();
        if($result=true){
            $_SESSION['massage']="product Deleted Successfully.";
        }else{
            $_SESSION['massage']="Sorry I couldn't Delete product. Please Try again.";
        }

        header('location:index.php');

    }
    public function edit(){
       $_id=$_GET['id'];
//connecting DB
        $this->conn=new PDO(
            "mysql:host=localhost;
    dbname=grupeco",
            "root",
            ""
        );
// set the PDO error mode to exception
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $query = "SELECT * FROM `products` WHERE id = :id ";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id',$_id);
        $result = $stmt->execute();
        $product = $stmt->fetch();
        return $product;

    }
    public function trash(){
        session_start();
        $_id=$_GET['id'];
        $_is_deleted=1;
        $query="UPDATE `products` SET `is_deleted`=:is_deleted WHERE `products`.`id`=:id";
        $stmt=$this->conn->prepare($query);
        $stmt->bindParam(":id",$_id);
        $stmt->bindParam(":is_deleted",$_is_deleted);
        $result=$stmt->execute();
        if($result=true){
            $_SESSION['massage']="product Deleted Successfully.";
        }else{
            $_SESSION['massage']="Sorry I couldn't Delete product. Please Try again.";
        }

        header('location:index.php');
    }
    public function trash_index(){
        //insert command through making querry
        $query="SELECT * FROM `products` WHERE `is_deleted`=1";

//prepare statement and bind it within DB

        $stmt=$this->conn->prepare($query);
        $result=$stmt->execute();
//fatch data from DB
        $product=$stmt->fetchAll();
        return $product;
    }


}