<?php


namespace App;
use PDO;


class Banner
{
    public $conn = null;

    public function __construct()
    {
        //Connection To Database
        $this->conn = new PDO("mysql:host=localhost;dbname=grupeco", "root", "");
// set the PDO error mode to exception
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    }

    public function index()
    {
       /* session_start();*/


//Insert Command
        $query = "SELECT * FROM `banners` WHERE is_deleted = 0";

//Prepare a statement
        $stmt= $this->conn->prepare($query);
        $result = $stmt->execute();
        $banners = $stmt->fetchAll();
        return $banners;
    }
    public function getActiveBanners()
    {
        /* session_start();*/
        $startfrom = 0;
        $total = 3;


//Insert Command
        $query = "SELECT * FROM `banners` WHERE is_active = 1 AND is_deleted = 0 LIMIT $startfrom,$total ";

//Prepare a statement
        $stmt= $this->conn->prepare($query);
        $result = $stmt->execute();
        $banners = $stmt->fetchAll();
        return $banners;
    }
    public function store($data)

    {
        $approot =  $_SERVER['DOCUMENT_ROOT'].'/grupeCo/';
        $webroot = "http://localhost/grupeCo/";
        //Working with image upload
        $file_name =  "IMG_".time()."_".$_FILES['picture']['name'];
        $target = $_FILES['picture']['tmp_name'];
        $destination = $approot.'uploads/'.$file_name;
        $is_file_moved = move_uploaded_file($target,$destination);

        if ($is_file_moved)
        {
            $_picture = $file_name;
        }
        else
        {
            $_picture = null;
        }



        $_title = $data['title'];
        $_detail = $data['detail'];
//$_is_delete = $_POST['is_delete'];
        if (array_key_exists('is_active',$data))
        {
            $_is_active = $data['is_active'];
        }
        else
        {
            $_is_active = 0;
        }


        if (array_key_exists('is_deleted',$data))
        {
            $_is_delete = $_POST['is_delete'];
        }
        else
        {
            $_is_delete = 0;
        }
        echo "<pre>";
        print_r($_FILES);
        echo "</pre>";
//echo $_title;
        $_created_at = date('Y-m-d h:i:s' , time());




/*//Connection To Database
        $conn = new PDO("mysql:host=localhost;dbname=practise", "root", "");
// set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);*/

//Insert Command
        $query = "INSERT INTO `banners`(`title` , `detail` ,`picture` , `is_active` , `is_deleted`,`created_at`) VALUES (:title , :detail , :picture , :is_active , :is_deleted , :created_at)";

//Prepare a statement
        $stmt= $this->conn->prepare($query);
        $stmt->bindParam(':title',$_title);
        $stmt->bindParam(':detail',$_detail);
        $stmt->bindParam(':picture',$_picture);
        $stmt->bindParam(':is_active',$_is_active);
        $stmt->bindParam(':is_deleted',$_is_delete);
        $stmt->bindParam(':created_at',$_created_at);
        $result = $stmt->execute();

//var_dump($result);
        if($result)
        {
            $_SESSION['message'] = "Banner is added successfully";
        }
        else
        {
            $_SESSION['message'] = "Banner is not added";
        }
        header("location:index.php");

    }
    public  function show($_id)
    {



//Insert Command
        $query = "SELECT * FROM `banners` WHERE id = :id";

//Prepare a statement
        $stmt= $this->conn->prepare($query);
        $stmt->bindParam(':id', $_id);
        $result = $stmt->execute();
        $banner = $stmt->fetch();
        return $banner;

        /*
        echo "<pre>";
        var_dump($banner);
        echo "</pre>";
        */
    }
    public function edit($_id)
    {



//echo $_id;


//Insert Command
        $query = "SELECT * FROM `banners` WHERE id = :id";

//Prepare a statement
        $stmt= $this->conn->prepare($query);
        $stmt->bindParam(':id', $_id);
        $result = $stmt->execute();
        $banner = $stmt->fetch();
        return $banner;

        /*
        echo "<pre>";
        var_dump($banner);
        echo "</pre>";
        */
    }
    public function update($data)
    {
        $approot =  $_SERVER['DOCUMENT_ROOT'].'/grupeCo/';

//Working with image upload
        if ($_FILES['picture']['name']!="") {
            $file_name = "IMG_" . time() . "_" . $_FILES['picture']['name'];
            $target = $_FILES['picture']['tmp_name'];
            $destination = $approot . 'uploads/' . $file_name;
            $is_file_moved = move_uploaded_file($target, $destination);

            if ($is_file_moved) {
                $_picture = $file_name;
            } else {
                $_picture = null;
            }

        }
        else
        {
            $_picture = $data['old_image'];
        }
        /*
        echo "<pre>";
        var_dump($_POST);
        echo "</pre>";
        */
        $_id = $data['id'];
        $_title = $data['title'];
        $_detail = $data['detail'];
//$_is_active = $_POST['is_active'];
//echo $_title;
        echo $_id;
        echo $_title;

        if(array_key_exists('is_active',$data)){
            $_is_active =$data['is_active'];
        }
        else{
            $_is_active = 0;
        }

        if(array_key_exists('is_deleted',$data)){
            $_is_delete =$_POST['is_delete'];
        }
        else{
            $_is_delete = 0;
        }

        $_modified_at = date('Y-m-d h:i:s' , time());

//Insert Command
        $query = "UPDATE `banners` SET `title` = :title , `detail` = :detail, `is_active` = :is_active ,`picture` = :picture , `modified_at` = :modified_at WHERE `banners`.`id` = :id; ";

//Prepare a statement
        $stmt= $this->conn->prepare($query);
        $stmt->bindParam(':id',$_id);
        $stmt->bindParam(':title',$_title);
        $stmt->bindParam(':detail',$_detail);
        $stmt->bindParam(':is_active',$_is_active);
        $stmt->bindParam(':picture',$_picture);
        $stmt->bindParam(':modified_at',$_modified_at);
        $result = $stmt->execute();

        if($result)
        {
            $_SESSION['message'] = "Banner is updated successfully";
        }
        else
        {
            $_SESSION['message'] = "Banner is not updated";
        }

//var_dump($result);
        header("location:index.php");
    }
    public function  delete($_id)
    {
        session_start();

//echo $_id;

//Insert Command
        $query = "DELETE FROM `banners` WHERE `banners`.`id` = :id";

//Prepare a statement
        $stmt= $this->conn->prepare($query);
        $stmt->bindParam(':id', $_id);
        $result = $stmt->execute();
        //var_dump($result);

        /*
        echo "<pre>";
        var_dump($banner);
        echo "</pre>";
        */

        if($result)
        {
            $_SESSION['message'] = "Banner is deleted successfully";
        }
        else
        {
            $_SESSION['message'] = "Banner is not deleted";
        }


        header("location:index.php");
    }
    public function trash($_id){
        session_start();

        $_is_delete = 1;
//echo $_id;

//Insert Command
        $query = "UPDATE `banners` SET `is_deleted` = :is_deleted WHERE `banners`.`id` = :id; ";

//Prepare a statement
        $stmt= $this->conn->prepare($query);
        $stmt->bindParam(':id', $_id);
        $stmt->bindParam(':is_deleted', $_is_delete);
        $result = $stmt->execute();
        var_dump($result);

        /*
        echo "<pre>";
        var_dump($banner);
        echo "</pre>";
        */

        if($result)
        {
            $_SESSION['message'] = "Banner is trashed successfully";
        }
        else
        {
            $_SESSION['message'] = "Banner is not trashed";
        }


        header("location:index.php");
    }
    public function trash_index()
    {
        /*session_start();*/

//Insert Command
        $query = "SELECT * FROM `banners` WHERE is_deleted = 1";

//Prepare a statement
        $stmt= $this->conn->prepare($query);
        $result = $stmt->execute();
        $banners = $stmt->fetchAll();
        return $banners;

        /*
          echo "<pre>";
        var_dump($banners);
        echo "</pre>";
         */
    }
    public function restore($_id)
    {
        session_start();

        $_is_delete = 0;
//echo $_id;

//Insert Command
        $query = "UPDATE `banners` SET `is_deleted` = :is_deleted WHERE `banners`.`id` = :id; ";

//Prepare a statement
        $stmt= $this->conn->prepare($query);
        $stmt->bindParam(':id', $_id);
        $stmt->bindParam(':is_deleted', $_is_delete);
        $result = $stmt->execute();
        var_dump($result);

        /*
        echo "<pre>";
        var_dump($banner);
        echo "</pre>";
        */

        if($result)
        {
            $_SESSION['message'] = "Banner is restored successfully";
        }
        else
        {
            $_SESSION['message'] = "Banner is not restored";
        }


        header("location:index.php");
    }
}