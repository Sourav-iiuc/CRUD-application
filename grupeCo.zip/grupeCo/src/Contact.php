<?php
/**
 * Created by PhpStorm.
 * User: PHP
 * Date: 11/26/2019
 * Time: 4:11 PM
 */

namespace App;
use PDO;


class Contact
{
    public function index(){
        $conn=new PDO(
            "mysql:host=localhost;
    dbname=grupeco",
            "root",
            ""
        );
//check error
        $conn->setAttribute(
            PDO::ATTR_ERRMODE,
            PDO::ERRMODE_EXCEPTION
        );

//insert command through making querry
        $query="SELECT * FROM `contacts`";

//prepare statement and bind it within DB

        $stmt=$conn->prepare($query);
        $result=$stmt->execute();
//fatch data from DB
        $contacts=$stmt->fetchAll();
        return $contacts;
    }
    public function store(){
        // defining variable according to the name field of form
        //session_start();
        $webroot = 'http://localhost/grupeCo/';

        $_name=$_POST['name'];
        $_email=$_POST['email'];
        $_comment=$_POST['comment'];
        $_subject=$_POST['subject'];

//connection to DB

        $conn=new PDO(
            "mysql:host=localhost;
    dbname=grupeco",
            "root",
            ""
        );
//check error
        $conn->setAttribute(
            PDO::ATTR_ERRMODE,
            PDO::ERRMODE_EXCEPTION
        );

//insert command through making querry
        $query="INSERT INTO `contacts`( `name`, `email`, `comment`, `subject`)  VALUES (:name,:email, :comment, :subject)";

//prepare statement and bind it within DB

        $stmt=$conn->prepare($query);
        $stmt->bindParam(":name",$_name);
        $stmt->bindParam(":email",$_email);
        $stmt->bindParam(":comment",$_comment);
        $stmt->bindParam(":subject",$_subject);

        $result=$stmt->execute();

//successfull massage setting
        if($result){
            $_SESSION['massage']="Admin Added Successfully.";
        }else{
            $_SESSION['massage']="Sorry I couldn't add contact. Please Try again.";
        }

        header('location:'.$webroot.'/front/public/index.php');
    }
    public function show(){
        $_id=$_GET['id'];
//connecting DB
        $conn=new PDO(
            "mysql:host=localhost;
    dbname=grupeco",
            "root",
            ""
        );
// set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $query = "SELECT * FROM `contacts` WHERE id = :id ";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id',$_id);
        $result = $stmt->execute();
        $contacts = $stmt->fetch();
        return $contacts;

    }
    public function delete(){
        session_start();
        $_id=$_GET['id'];
//connection to DB

        $conn=new PDO(
            "mysql:host=localhost;
    dbname=grupeco",
            "root",
            ""
        );
//check error
        $conn->setAttribute(
            PDO::ATTR_ERRMODE,
            PDO::ERRMODE_EXCEPTION
        );
        $query="DELETE FROM `contacts` WHERE `id`=:id";
        $stmt=$conn->prepare($query);
        $stmt->bindParam(":id",$_id);
        $result=$stmt->execute();
        if($result){
            $_SESSION['massage']="contact Deleted Successfully.";
        }else{
            $_SESSION['massage']="Sorry I couldn't Delete contact. Please Try again.";
        }

        header('location:index.php');
    }

}