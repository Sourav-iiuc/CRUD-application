<?php
header('location:./front/public/');
?>